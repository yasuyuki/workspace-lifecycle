from __future__ import annotations

from contextlib import ExitStack, contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import uuid

from .errors import LifecycleError
from .git import bound_task, branch_for_task, current_branch, git, head, remote_default, task_worktree, top, worktree_records
from .state import locked_state, save_state


def _now(): return datetime.now(timezone.utc).isoformat()
def _sha(path: Path): return hashlib.sha256(path.read_bytes()).hexdigest()


@contextmanager
def _lease(repo, task, allow_use=False):
    # This is intentionally mandatory: a missing lease module means a partial
    # installation must not mutate a workspace.
    try:
        from .leases import guard
    except ImportError as exc:
        raise LifecycleError("workspace lifecycle lease support is unavailable") from exc
    try:
        with guard(repo, task, allow_use=allow_use):
            yield
    except (ValueError, OSError) as exc:
        raise LifecycleError(str(exc)) from exc


def _snapshot(repo: Path, *, optional_locks=True, excluded=()) -> dict[str, str]:
    pathspec = ['--', '.', *(':(exclude,literal)' + name for name in excluded)] if excluded else []
    environment = None if optional_locks else {**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}
    process = subprocess.run(['git', '-C', str(repo), 'status', '--porcelain=v1', '-z',
                              '--untracked-files=all', '--ignored=no', '--no-renames', *pathspec],
                             capture_output=True, check=True, env=environment)
    result = {os.fsdecode(row[3:]): os.fsdecode(row[:2]) for row in process.stdout.split(b'\0') if row}
    ignored = subprocess.run(['git', '-C', str(repo), 'ls-files', '--others', '--ignored',
                              '--exclude-standard', '-z', *pathspec], capture_output=True, check=True)
    result.update({os.fsdecode(row): '!!' for row in ignored.stdout.split(b'\0') if row})
    return result


def _task(state, task):
    value = state['tasks'].get(task)
    if not value:
        raise LifecycleError('unknown task: ' + task)
    return value


def _no_links(path, stop=None):
    # Windows canonicalization expands 8.3 paths and normalizes casing. That is
    # not a link. Check the actual filesystem attributes on every existing part.
    for component in (path, *path.parents):
        try:
            info = component.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400):
            raise LifecycleError('workspace path cannot traverse a link or reparse point')
        if component == stop:
            break


def begin(repo, *, task: str, request: str, remote: str, branch: str, worktree: str,
          parent: str | None = None, dependencies: list[str] | None = None,
          validation: list[str] | None = None, preflight: list[str] | None = None) -> dict:
    repo = Path(repo).resolve(); dependencies = dependencies or []
    if not task or not request or not branch or not worktree or '\n' in task or '\0' in task:
        raise LifecycleError('task, request, branch, and worktree are required')
    for value in (validation, preflight):
        if not isinstance(value, list) or not value or not all(isinstance(x, str) and x for x in value):
            raise LifecycleError('validation and preflight require nonempty argv arrays')
    if '{repo}' not in preflight:
        raise LifecycleError('preflight must explicitly select {repo}')
    git(repo, 'check-ref-format', '--branch', branch)
    target = Path(worktree).absolute()
    _no_links(target)
    target = target.resolve()
    if target == top(repo) or top(repo) in target.parents:
        raise LifecycleError('new worktree must be outside the integration checkout')
    desired = {'branch': branch, 'worktree': str(target), 'request': request, 'remote': remote,
               'parent': parent, 'dependencies': dependencies, 'validation': validation, 'preflight': preflight}
    with ExitStack() as stack:
        for identity in sorted({task, *dependencies, *([parent] if parent else [])}):
            stack.enter_context(_lease(repo, identity))
        with locked_state(repo, create=True) as (directory, state):
            if task in state['tasks'] or task in state.get('retired', {}):
                raise LifecycleError('task already exists; resume its existing checkout')
            intent = state['intents'].get(task)
            if intent and (intent.get('kind') != 'begin' or intent.get('desired') != desired):
                raise LifecycleError('pending begin must resume its exact requested identity')
            if not intent:
                if target.exists() or git(repo, 'show-ref', '--verify', '--quiet', 'refs/heads/' + branch, optional=True) is not None:
                    raise LifecycleError('new lifecycle worktree and branch must not already exist')
                default = remote_default(repo, remote)
                if branch == default:
                    raise LifecycleError('default branch is an integration destination, not a new task')
                if set(dependencies) - set(state['tasks']) or task in dependencies:
                    raise LifecycleError('dependencies must refer to existing other tasks')
                if any(state['tasks'][name].get('retire') for name in dependencies):
                    raise LifecycleError('dependency is retiring')
                if parent:
                    parent_task = _task(state, parent)
                    if parent_task.get('hold') or parent_task.get('retire'):
                        raise LifecycleError('parent is held or retiring')
                    if parent_task['remote'] != remote:
                        raise LifecycleError('parent and child must use the same remote contract')
                    base = head(repo, 'refs/heads/' + branch_for_task(repo, parent))
                    integration = {'kind': 'task', 'task': parent}
                else:
                    git(repo, 'fetch', remote, 'refs/heads/' + default)
                    base = head(repo, 'FETCH_HEAD')
                    integration = {'kind': 'remote-default', 'remote': remote}
                # This is a transient operation intent, not a live Git-state mirror.
                intent = {'kind': 'begin', 'desired': desired, 'base': base,
                          'integration': integration, 'at': _now()}
                state['intents'][task] = intent; save_state(directory, state)
            base = intent['base']
            records = [r for r in worktree_records(repo) if Path(r['worktree']).resolve() == target]
            existing = git(repo, 'show-ref', '--verify', '--hash', 'refs/heads/' + branch, optional=True)
            if records:
                if (len(records) != 1 or records[0].get('branch') != 'refs/heads/' + branch
                        or head(target) != base or _snapshot(target)):
                    raise LifecycleError('interrupted begin checkout changed; preserve it for review')
            elif existing:
                if existing != base or target.exists():
                    raise LifecycleError('interrupted begin branch or destination changed')
                git(repo, 'worktree', 'add', str(target), branch)
            else:
                if target.exists():
                    raise LifecycleError('interrupted begin destination appeared without Git identity')
                git(repo, 'worktree', 'add', '-b', branch, str(target), base)
            key = 'branch.' + branch + '.workspaceTask'
            binding = git(repo, 'config', '--local', '--get', key, optional=True)
            if binding and binding != task:
                raise LifecycleError('branch binding belongs to another task')
            git(repo, 'config', '--local', key, task)
            state['tasks'][task] = {'request': request, 'remote': remote,
                'integration': intent['integration'], 'dependencies': dependencies,
                'validation': validation, 'preflight': preflight,
                'baseline_dirty': _snapshot(target), 'created_at': _now()}
            state['intents'].pop(task); save_state(directory, state)
    return {'task': task, 'branch': branch, 'base': base, 'worktree': str(target)}


def status(repo, task: str | None = None) -> dict:
    repo = Path(repo).resolve()
    with locked_state(repo) as (_, state):
        if task is None:
            try: task = bound_task(repo)
            except LifecycleError:
                return {"tasks": [{"task": name, "completion": "exception" if item.get("exception") else ("accepted" if item.get("acceptance") else "active"), "retire_pending": bool(item.get("retire"))} for name, item in state["tasks"].items()]}
        data = _task(state, task).copy()
        branch = branch_for_task(repo, task)
        try:
            live = task_worktree(repo, branch)
            data["live"] = {"branch": branch, "head": head(live), "worktree": str(live), "dirty": _snapshot(live, excluded=_preserved_paths(data))}
        except LifecycleError as exc: data["live_error"] = str(exc)
        data["task"] = task
        data["completion"] = "exception" if data.get("exception") else ("accepted" if data.get("acceptance") else "active")
        if task in state["intents"]: data["intent"] = state["intents"][task]
        return data


def update_preflight(repo, *, task: str, expected_preflight: list[str],
                     preflight: list[str], evidence: str) -> dict:
    """Change one current task's push policy command under an exact argv CAS."""
    for name, argv in (("expected preflight", expected_preflight), ("preflight", preflight)):
        if not isinstance(argv, list) or not argv or not all(isinstance(x, str) and x for x in argv):
            raise LifecycleError(name + ' requires a nonempty string argv array')
    if '{repo}' not in preflight:
        raise LifecycleError('preflight must explicitly select {repo}')
    if not isinstance(evidence, str) or not evidence.strip():
        raise LifecycleError('preflight update requires durable evidence')
    with _lease(repo, task):
        with locked_state(repo) as (directory, state):
            item = _task(state, task)
            if task in state.get('intents', {}) or item.get('retire'):
                raise LifecycleError('pending task operation prevents preflight update')
            if item.get('preflight') != expected_preflight:
                raise LifecycleError('preflight CAS mismatch')
            item['preflight'] = list(preflight)
            item['preflight_update'] = {'from': list(expected_preflight), 'to': list(preflight),
                                        'evidence': evidence, 'at': _now()}
            save_state(directory, state)
    return {'task': task, 'preflight': list(preflight)}


def update_validation(repo, *, task: str, expected_head: str,
                      expected_validation: list[str], validation: list[str], evidence: str) -> dict:
    """Correct an unaccepted task's validator without changing its contract history."""
    repo = top(repo)
    if (not isinstance(expected_validation, list)
            or not all(isinstance(x, str) and x for x in expected_validation)):
        raise LifecycleError('expected validation requires a string argv array')
    if (not isinstance(validation, list) or not validation
            or not all(isinstance(x, str) and x for x in validation)):
        raise LifecycleError('validation requires a nonempty string argv array')
    if not isinstance(evidence, str) or not evidence.strip():
        raise LifecycleError('validation update requires durable evidence')
    with _lease(repo, task):
        with locked_state(repo) as (directory, state):
            item = _task(state, task)
            if task in state.get('intents', {}) or item.get('retire'):
                raise LifecycleError('pending task operation prevents validation update')
            if item.get('acceptance'):
                raise LifecycleError('accepted task validation cannot be replaced')
            branch = branch_for_task(repo, task)
            identity = _finish_identity(repo, task, branch)
            if expected_head != head(repo):
                raise LifecycleError('validation update HEAD mismatch; supply the exact full commit OID')
            _operation_check(repo, 'validation update')
            if item.get('validation') != expected_validation:
                raise LifecycleError('validation CAS mismatch')
            receipt = {'from': list(expected_validation), 'to': list(validation),
                       'evidence': evidence, 'head': expected_head, 'identity': identity, 'at': _now()}
            _operation_check(repo, 'validation update')
            if _finish_identity(repo, task, branch) != identity or head(repo) != expected_head:
                raise LifecycleError('HEAD or identity changed during validation update')
            item['validation'] = list(validation)
            item.setdefault('validation_updates', []).append(receipt)
            save_state(directory, state)
    return {'task': task, 'validation': list(validation)}


def hold(repo, task: str, reason: str, next_action: str) -> dict:
    if not reason or not next_action: raise LifecycleError("hold requires reason and next action")
    with _lease(repo, task, allow_use=True):
        with locked_state(repo) as (directory, state):
            _task(state, task)["hold"] = {"reason": reason, "next_action": next_action, "at": _now()}
            save_state(directory, state)
    return {"task": task, "held": True}


def release_hold(repo, task, evidence):
    if not isinstance(evidence, str) or not evidence.strip():
        raise LifecycleError('explicit hold resolution evidence is required')
    with _lease(repo, task, allow_use=True):
        with locked_state(repo) as (directory, state):
            item = _task(state, task)
            if not item.get('hold'):
                raise LifecycleError('task has no hold to resolve')
            item.pop('hold')
            item['hold_resolution'] = evidence
            save_state(directory, state)
    return {'task': task, 'held': False}


def _validate(repo: Path, argv: list[str]) -> dict:
    if not argv: return {"argv": [], "returncode": 0}
    argv = [str(repo) if value == "{repo}" else value for value in argv]
    result = subprocess.run(argv, cwd=repo, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    evidence = {"argv": argv, "returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
    if result.returncode: raise LifecycleError("configured validation failed: " + json.dumps(evidence, ensure_ascii=True))
    return evidence


def _push(repo: Path, preflight: list[str], expected_branch: str, expected_remote=None, expected_head=None) -> dict:
    remote_url = git(repo, 'remote', 'get-url', expected_remote) if expected_remote else None
    argv = [str(repo) if value == "{repo}" else value for value in preflight]
    if "{repo}" not in preflight: raise LifecycleError("preflight argv must contain literal {repo}")
    result = subprocess.run(argv, cwd=repo, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode: raise LifecycleError("push preflight failed")
    try: decision = json.loads(result.stdout)
    except json.JSONDecodeError as exc: raise LifecycleError("push preflight did not emit JSON") from exc
    if decision.get("decision") != "push": raise LifecycleError("push blocked: " + str(decision.get("reason", "unknown")))
    push_argv = decision.get("push_argv")
    if not isinstance(push_argv, list) or len(push_argv) != 4 or push_argv[:2] != ["git", "push"] or not isinstance(push_argv[2], str) or push_argv[3] != "HEAD:refs/heads/" + expected_branch:
        raise LifecycleError("preflight push argv is not an exact normal branch push")
    if push_argv[2].startswith('-') or (expected_remote is not None and push_argv[2] != expected_remote):
        raise LifecycleError('preflight selected a different remote than the registered integration contract')
    if expected_head is not None and (head(repo) != expected_head or current_branch(repo) != expected_branch):
        raise LifecycleError('HEAD or branch changed before pushing the revised finish')
    if remote_url is not None and git(repo, 'remote', 'get-url', expected_remote) != remote_url:
        raise LifecycleError('remote URL changed during push preflight')
    expected = expected_head or head(repo)
    failure = None
    try:
        subprocess.run(push_argv, cwd=repo, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8")
    except subprocess.CalledProcessError as exc:
        failure = exc  # The remote may have accepted before the response vanished.
    if remote_url is not None and git(repo, 'remote', 'get-url', expected_remote) != remote_url:
        raise LifecycleError('remote URL changed while pushing finish')
    remote_tip = _remote_tip(repo, push_argv[2], expected_branch)
    if head(repo) != expected or current_branch(repo) != expected_branch:
        raise LifecycleError('HEAD or branch changed while pushing finish')
    if remote_tip != expected:
        git(repo, 'fetch', push_argv[2], 'refs/heads/' + expected_branch)
        fetched = head(repo, 'FETCH_HEAD')
        if fetched != remote_tip or git(repo, 'merge-base', '--is-ancestor', expected, fetched, optional=True) is None:
            if failure:
                raise failure
            raise LifecycleError('push did not verify remote preservation of the expected commit')
    return {"decision": decision["decision"], "reason": decision.get("reason"), "argv": push_argv,
            "commit": expected, "remote_observed": remote_tip,
            "response_recovered": failure is not None}



def _plan(path: Path):
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise LifecycleError("invalid finish plan") from exc
    if not isinstance(value, dict) or set(value) - {"commit", "restore", "archive", "exception"}:
        raise LifecycleError("finish plan has unknown fields")
    for key in ("commit", "restore", "archive"):
        if key in value and not isinstance(value[key], list):
            raise LifecycleError("plan " + key + " must be a list")
    return value


def _file_path(repo, name):
    relative = Path(name)
    if relative.is_absolute() or not relative.parts or any(part.casefold() in ("..", ".git") for part in relative.parts):
        raise LifecycleError("path must name a workspace file outside Git metadata")
    candidate = repo / relative
    _no_links(candidate, repo)
    if repo not in candidate.resolve().parents:
        raise LifecycleError("plan path escapes workspace")
    for parent in candidate.parents:
        if parent == repo:
            break
        marker = parent / '.git'
        if marker.exists() or marker.is_symlink():
            raise LifecycleError('plan path belongs to a nested Git checkout')
    return candidate


def _checked_paths(repo, entries, *, need, owner, completed=None):
    paths = []
    for item in entries:
        if (not isinstance(item, dict) or not isinstance(item.get("path"), str)
                or item.get("classification") != need or item.get("owner") != owner
                or not isinstance(item.get("evidence"), str) or not item['evidence'].strip()):
            raise LifecycleError("each plan entry needs exact path, classification, task owner and ownership evidence")
        name = item['path']
        candidate = _file_path(repo, name)
        if completed and name in completed:
            paths.append(name)
            continue
        if need == 'source' and item.get('deleted') is True:
            previous = subprocess.run(['git', '-C', str(repo), 'cat-file', '--filters', 'HEAD:' + name], capture_output=True)
            # After a recorded commit, the exact before-image remains in its parent.
            if previous.returncode:
                previous = subprocess.run(['git', '-C', str(repo), 'cat-file', '--filters', 'HEAD^:' + name], capture_output=True)
            if (candidate.exists() or candidate.is_symlink() or previous.returncode
                    or hashlib.sha256(previous.stdout).hexdigest() != item.get('before_sha256')):
                raise LifecycleError('deleted source does not match its reviewed before-image')
        elif not candidate.is_file() or item.get('sha256') != _sha(candidate):
            raise LifecycleError("plan file disappeared or content hash changed: " + name)
        if need == 'source':
            if item.get('safe_to_commit') is not True:
                raise LifecycleError('source requires explicit safe-to-commit attestation')
            if git(repo, 'check-ignore', '--quiet', '--', name, optional=True) is not None:
                raise LifecycleError('ignored data cannot be committed by finish')
        paths.append(name)
    return paths


def _exception(plan, paths):
    exception = plan.get('exception')
    alternatives = exception.get('alternatives') if isinstance(exception, dict) else None
    categories = {x.get('category') for x in alternatives if isinstance(x, dict)} if isinstance(alternatives, list) else set()
    if (not isinstance(exception, dict) or exception.get('reviewed_all_alternatives') is not True
            or not isinstance(alternatives, list) or len(alternatives) != 4
            or categories != {'commit', 'restore', 'archive', 'owner-resolution'}
            or not exception.get('remaining_owner') or not exception.get('next_action')
            or any(not x.get('irreversible_harm') or not x.get('evidence') for x in alternatives)):
        raise LifecycleError('unresolved dirty is not a completion exception: review all applicable alternatives and preserve evidence/owner/next action')
    return {**exception, 'paths': sorted(paths), 'at': _now()}


def _index_paths(repo):
    result = subprocess.run(['git', '-C', str(repo), 'diff', '--cached', '--name-only', '-z'], capture_output=True, check=True)
    return {os.fsdecode(x) for x in result.stdout.split(b'\0') if x}


def _index_protection(repo):
    result = subprocess.run(['git', '-C', str(repo), 'ls-files', '-v', '-z'], capture_output=True, check=True)
    if any(row[:1].islower() or row[:1] == b'S' for row in result.stdout.split(b'\0') if row):
        raise LifecycleError('index assume-unchanged/skip-worktree flags require explicit owner resolution')
    if git(repo, 'ls-files', '--unmerged'):
        raise LifecycleError('unmerged index must be resolved in its existing worktree')


def _operation_check(target, operation='adoption'):
    _index_protection(target)
    for name in ('MERGE_HEAD', 'REBASE_HEAD', 'CHERRY_PICK_HEAD', 'REVERT_HEAD',
                 'rebase-merge', 'rebase-apply', 'sequencer', 'BISECT_START', 'BISECT_LOG', 'index.lock'):
        path = Path(git(target, 'rev-parse', '--path-format=absolute', '--git-path', name))
        if path.exists() or path.is_symlink():
            raise LifecycleError('existing Git operation must be resolved before ' + operation + ': ' + name)


def _finish_identity(repo, task_id, branch):
    if (branch_for_task(repo, task_id) != branch or top(repo) != task_worktree(repo, branch)
            or current_branch(repo) != branch or bound_task(repo) != task_id):
        raise LifecycleError('finish must run in the bound task worktree')
    admin = Path(git(repo, 'rev-parse', '--absolute-git-dir')).resolve()
    return {'task': task_id, 'branch': branch, 'worktree': str(repo), 'git_dir': str(admin),
            'worktree_id': [repo.stat().st_dev, repo.stat().st_ino],
            'git_dir_id': [admin.stat().st_dev, admin.stat().st_ino]}


def _sync_file(path):
    with path.open('r+b') as stream:
        os.fsync(stream.fileno())
    if os.name != 'nt':
        descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)


def _resolve_files(repo, plan, intent, directory, state):
    for entry in plan.get('archive', []):
        name = entry['path']; source = _file_path(repo, name)
        approval = entry.get('approval_evidence')
        store = Path(entry.get('store', ''))
        if not approval or not store.is_absolute() or not store.is_dir():
            raise LifecycleError('archive needs an explicit existing authorized absolute store and approval evidence')
        _no_links(store)
        store = store.resolve()
        if store == repo or repo in store.parents or git(store, 'rev-parse', '--show-toplevel', optional=True):
            raise LifecycleError('private archive store cannot be inside a Git worktree')
        filename = entry.get('name', source.name)
        if not isinstance(filename, str) or Path(filename).name != filename or filename in ('.', '..'):
            raise LifecycleError('archive destination name must be a filename')
        destination = store / filename
        action = intent['actions'].get(name)
        if action:
            if action['destination'] != str(destination) or action['sha256'] != entry['sha256']:
                raise LifecycleError('archive recovery identity differs')
        else:
            if destination.exists() or destination.is_symlink():
                raise LifecycleError('archive destination exists without this task preservation receipt')
            action = {'kind': 'archive', 'destination': str(destination),
                      'sha256': entry['sha256'], 'phase': 'copying'}
            intent['actions'][name] = action
            save_state(directory, state)
        if destination.is_symlink():
            raise LifecycleError('archive destination became a link')
        if action['phase'] == 'copying':
            if not source.is_file() or _sha(source) != entry['sha256']:
                raise LifecycleError('private source changed during preservation')
            if destination.exists():
                partial = destination.read_bytes()
                if not source.read_bytes().startswith(partial):
                    raise LifecycleError('partial archive was changed outside this operation')
                with destination.open('ab') as output, source.open('rb') as incoming:
                    incoming.seek(len(partial)); shutil.copyfileobj(incoming, output)
                    output.flush(); os.fsync(output.fileno())
            else:
                fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                with os.fdopen(fd, 'wb') as output, source.open('rb') as incoming:
                    shutil.copyfileobj(incoming, output)
                    output.flush(); os.fsync(output.fileno())
        elif not destination.is_file() or _sha(destination) != entry['sha256']:
            raise LifecycleError('preserved archive changed; keep remaining workspace data')
        if action['phase'] == 'copying':
            _sync_file(destination)
        if _sha(destination) != entry['sha256']:
            raise LifecycleError('archive readback differs')
        action = intent['actions'][name]
        action['phase'] = 'preserved'; save_state(directory, state)
        if source.exists():
            if source.is_symlink() or _sha(source) != entry['sha256']:
                raise LifecycleError('private source changed after archive; preserve both')
            shutil.copystat(source, destination)
            source.unlink()
        action['phase'] = 'resolved'; save_state(directory, state)
    for entry in plan.get('restore', []):
        name = entry['path']; path = _file_path(repo, name)
        proof = entry.get('regeneration')
        if not isinstance(proof, dict) or not proof.get('evidence'):
            raise LifecycleError('restore needs verified regeneration evidence')
        action = intent['actions'].get(name)
        if action and action['phase'] == 'resolved':
            continue
        tracked = git(repo, 'ls-files', '--error-unmatch', '--', name, optional=True) is not None
        if action and not path.exists() and not tracked:
            action['phase'] = 'resolved'; save_state(directory, state)
            continue
        original = subprocess.run(['git', '-C', str(repo), 'cat-file', '--filters', 'HEAD:' + name], capture_output=True)
        restored = tracked and original.returncode == 0 and path.is_file() and path.read_bytes() == original.stdout
        if not restored and (not path.is_file() or _sha(path) != entry['sha256']):
            raise LifecycleError('generated output changed before restore')
        intent['actions'][name] = {'kind': 'restore', 'phase': 'restoring'}
        save_state(directory, state)
        if tracked:
            git(repo, 'restore', '--source=HEAD', '--staged', '--worktree', '--', name)
        elif path.exists():
            path.unlink()  # exact owned reproducible file, never a recursive clean
        intent['actions'][name]['phase'] = 'resolved'; save_state(directory, state)




def _durable_preservation_evidence(value: str | None) -> str | None:
    if value is None:
        return None
    if not value or '\n' in value or '\0' in value:
        raise LifecycleError('reclaim requires durable preservation evidence')
    return value


def _bind_preservation_evidence(stored, incoming: str | None):
    incoming = _durable_preservation_evidence(incoming)
    if incoming is None:
        return stored
    if stored and stored != incoming:
        raise LifecycleError('preservation evidence changed')
    return incoming


def _preserved_paths(item):
    return [name for value in item.get('adoption', {}).get('preserved_snapshot', {}).values()
            for name in value['protected_paths']]


def _check_preserved(repo, item, incoming=None):
    from .preserved import check, overlap
    check(repo, item)
    protected = _preserved_paths(item)
    if not protected:
        return
    changes = _index_paths(repo)
    if incoming:
        raw = subprocess.run(['git', '-C', str(repo), 'diff', '--name-only', '-z',
                              'HEAD', incoming], check=True, capture_output=True).stdout
        changes.update(os.fsdecode(row) for row in raw.split(b'\0') if row)
    if any(overlap(name, protected) for name in changes):
        raise LifecycleError('Git changes overlap preserved data')


def _check_preserved_plan(item, plan):
    from .preserved import overlap
    protected = _preserved_paths(item)
    if not protected:
        return
    for category in ('commit', 'restore', 'archive'):
        for entry in plan.get(category, []):
            if isinstance(entry, dict) and isinstance(entry.get('path'), str):
                path = Path(entry['path'])
                if any(part.casefold() in ('.git', '..') for part in path.parts):
                    raise LifecycleError('path must name a workspace file outside Git metadata')
                if overlap(entry['path'], protected):
                    raise LifecycleError('plan path belongs to preserved data')


def _primary_workspace_data(repo: Path, task: dict, dirty: dict[str, str]) -> set[str]:
    """Dirt an adopted primary checkout may keep after acceptance.

    The primary checkout is never retired, so ignored workspace data and
    entries unchanged since adoption are not leftovers of this task. Linked
    worktrees and anything the task changed keep blocking acceptance.
    """
    if not task.get('adoption') or repo != Path(worktree_records(repo)[0]['worktree']).resolve():
        return set()
    baseline = task['baseline_dirty']
    return {name for name, kind in dirty.items() if kind == '!!' or baseline.get(name) == kind}


def finish(repo, *, task: str, plan_path: str, result_ref: str, message: str = 'workspace lifecycle completion', users_released: bool = False, revision_evidence: str | None = None, preservation_evidence: str | None = None, revision_head: str | None = None) -> dict:
    repo = Path(repo).resolve(); plan = _plan(Path(plan_path)); task_id = task
    reclaim_evidence = _durable_preservation_evidence(preservation_evidence)
    if not isinstance(result_ref, str) or not result_ref.strip():
        raise LifecycleError('durable result reference is required')
    if result_ref.startswith(str(repo)):
        raise LifecycleError('result must be preserved outside the retiring workspace')
    if revision_evidence is not None and (not isinstance(revision_evidence, str) or not revision_evidence.strip()):
        raise LifecycleError('finish revision requires nonempty durable evidence')
    if revision_head is not None and (not revision_evidence or not isinstance(revision_head, str)
                                     or not revision_head or any(c not in '0123456789abcdef' for c in revision_head)):
        raise LifecycleError('HEAD revision requires a full commit OID and durable evidence')
    plan_digest = hashlib.sha256(json.dumps(plan, sort_keys=True).encode()).hexdigest()
    with _lease(repo, task_id, allow_use=True):
        with locked_state(repo) as (directory, state):
            task = _task(state, task_id); branch = branch_for_task(repo, task_id)
            identity = _finish_identity(repo, task_id, branch)
            _check_preserved(repo, task)
            _check_preserved_plan(task, plan)
            if task.get('hold'):
                raise LifecycleError('task is held: ' + json.dumps(task['hold']))
            _index_protection(repo)
            intent = state['intents'].get(task_id)
            if intent and intent.get('identity', identity) != identity:
                raise LifecycleError('finish intent task or worktree identity changed')
            accepted_revision_retry = False
            if revision_head is not None:
                if not intent or intent['kind'] != 'finish':
                    # Acceptance may have been saved before an interrupted
                    # integration. Repeating the recovery arguments still joins
                    # that ordinary integration; it never starts a new revision.
                    receipts = task.get('finish_receipts', [])
                    previous = receipts[-1] if receipts else {}
                    if (previous.get('new_initial_head') != revision_head
                            or previous.get('revision_evidence') != revision_evidence
                            or previous.get('revised_plan_digest') != plan_digest
                            or previous.get('result_ref') != result_ref
                            or previous.get('revision_identity') != identity
                            or task.get('acceptance', {}).get('commit') != head(repo)):
                        raise LifecycleError('HEAD revision requires a pending finish intent or its exact accepted retry')
                    accepted_revision_retry = True
                elif intent.get('head_revision'):
                    revision = intent['head_revision']
                    if (revision['head'] != revision_head or revision['evidence'] != revision_evidence
                            or intent['plan_digest'] != plan_digest or intent['result_ref'] != result_ref):
                        raise LifecycleError('retry HEAD revision with the same head, evidence, plan and result')
                    _operation_check(repo, 'finish HEAD revision')
                else:
                    if intent['actions'] != {} or 'committed' in intent or 'commit_tree' in intent:
                        raise LifecycleError('HEAD revision requires a finish intent with no started effects')
                    if intent['result_ref'] != result_ref:
                        raise LifecycleError('HEAD revision requires the same durable result reference')
                    old_head = intent['initial_head']
                    if len(revision_head) != len(old_head) or revision_head == old_head or head(repo) != revision_head:
                        raise LifecycleError('HEAD changed or does not match the requested revision head')
                    _operation_check(repo, 'finish HEAD revision')
                    if git(repo, 'merge-base', '--is-ancestor', old_head, revision_head, optional=True) is None:
                        raise LifecycleError('revision head must descend from the original finish HEAD')
                    # The lifecycle lock cannot serialize native Git writers. Pin
                    # the caller-reviewed OID and compare again before replacement;
                    # a later move is refused by the ordinary pinned-HEAD check.
                    if _finish_identity(repo, task_id, branch) != identity or head(repo) != revision_head:
                        raise LifecycleError('HEAD or identity changed during finish revision')
                    _operation_check(repo, 'finish HEAD revision')
                    revised_at = _now()
                    replacement = {'kind': 'finish', 'initial_head': revision_head,
                                   'plan_digest': plan_digest, 'result_ref': result_ref,
                                   'actions': {}, 'at': revised_at, 'identity': identity,
                                   'head_revision': {'head': revision_head, 'evidence': revision_evidence}}
                    task.setdefault('finish_receipts', []).append({**intent,
                        'revision_evidence': revision_evidence, 'revised_at': revised_at,
                        'old_initial_head': old_head, 'new_initial_head': revision_head,
                        'revised_plan_digest': plan_digest, 'revision_identity': identity})
                    state['intents'][task_id] = intent = replacement
                    save_state(directory, state)
            elif intent and intent.get('head_revision') and revision_evidence is not None:
                if (intent['head_revision']['evidence'] != revision_evidence
                        or intent['plan_digest'] != plan_digest or intent['result_ref'] != result_ref):
                    raise LifecycleError('retry HEAD revision with the same head, evidence, plan and result')
            if accepted_revision_retry or (intent and intent['kind'] != 'finish'):
                # A preserved integration operation belongs to _integrate; do
                # not replace it or recommit the accepted source on resume.
                accepted = task.get('acceptance')
                if not accepted or accepted['commit'] != head(repo):
                    raise LifecycleError('pending operation does not match accepted source')
                commit = accepted['commit']
                if reclaim_evidence is not None:
                    task['preservation_evidence'] = _bind_preservation_evidence(
                        task.get('preservation_evidence'), reclaim_evidence)
                if users_released:
                    task['completion_release'] = {'result_ref': result_ref}
                    if task.get('owner_receipts'):
                        task['owner_release'] = {'result_ref': result_ref, 'commit': commit}
                if reclaim_evidence is not None or users_released:
                    save_state(directory, state)
            else:
                if intent and (intent['plan_digest'] != plan_digest or intent['result_ref'] != result_ref):
                    if not revision_evidence or intent['result_ref'] != result_ref:
                        raise LifecycleError('unfinished finish requires the same reviewed plan and result, or explicit plan revision evidence')
                    if head(repo) not in (intent['initial_head'], intent.get('committed')):
                        raise LifecycleError('resolve interrupted commit identity before revising its plan')
                    if any(action['phase'] != 'resolved' for action in intent['actions'].values()):
                        raise LifecycleError('finish pending preservation actions before revising the plan')
                    for action in intent['actions'].values():
                        if action['kind'] == 'archive':
                            saved = Path(action['destination'])
                            if not saved.is_file() or saved.is_symlink() or _sha(saved) != action['sha256']:
                                raise LifecycleError('previous preservation evidence changed')
                    task.setdefault('finish_receipts', []).append({**intent, 'revision_evidence': revision_evidence})
                    intent = None
                if not intent:
                    intent = {'kind': 'finish', 'initial_head': head(repo), 'plan_digest': plan_digest,
                              'result_ref': result_ref, 'actions': {}, 'at': _now(), 'identity': identity}
                    state['intents'][task_id] = intent
                    save_state(directory, state)
                if intent.get('head_revision'):
                    if _finish_identity(repo, task_id, branch) != identity:
                        raise LifecycleError('finish identity changed after HEAD revision')
                    _operation_check(repo, 'finish HEAD revision')
                synchronized_head = intent.get('synchronization', {}).get('commit')
                if intent.get('synchronization') and not synchronized_head:
                    raise LifecycleError('resume the pending synchronization before finish')
                if head(repo) not in {intent['initial_head'], intent.get('committed'), synchronized_head}:
                    # Crash after commit but before receipt: prove the exact
                    # planned tree and sole parent from native immutable objects.
                    expected_tree = intent.get('commit_tree')
                    parents = (git(repo, 'rev-list', '--parents', '-n', '1', 'HEAD') or '').split()
                    if not expected_tree or git(repo, 'rev-parse', 'HEAD^{tree}') != expected_tree or parents[1:] != [intent['initial_head']]:
                        raise LifecycleError('HEAD changed outside this finish intent')
                    intent['committed'] = head(repo); save_state(directory, state)
                resolved = {name for name, action in intent['actions'].items() if action['phase'] in ('resolved', 'preserved', 'restoring')}
                commit_paths = _checked_paths(repo, plan.get('commit', []), need='source', owner=task_id,
                    completed={entry['path'] for entry in plan.get('commit', [])} if synchronized_head and intent.get('committed') else None)
                restore_paths = _checked_paths(repo, plan.get('restore', []), need='reproducible', owner=task_id, completed=resolved)
                archive_paths = _checked_paths(repo, plan.get('archive', []), need='private', owner=task_id, completed=resolved)
                all_paths = commit_paths + restore_paths + archive_paths
                if len(all_paths) != len(set(all_paths)):
                    raise LifecycleError('plan categories overlap')
                protected = task.get('adoption', {}).get('protected_paths', [])
                if any(path == boundary or path.startswith(boundary + '/')
                       for path in all_paths for boundary in protected):
                    raise LifecycleError('plan path belongs to a preserved nested Git checkout')
                if any(path == baseline or (baseline.endswith('/') and path.startswith(baseline))
                       for path in all_paths for baseline in task['baseline_dirty']):
                    raise LifecycleError('preexisting dirty is not owned by this task')
                if _index_paths(repo) - set(commit_paths + restore_paths):
                    raise LifecycleError('index contains changes outside the owned finish plan')
                dirty = _snapshot(repo, excluded=_preserved_paths(task))
                uncovered = set(dirty) - set(all_paths)
                # Safe owned actions run first. Remaining dirt is never waived
                # merely because it existed before this session.
                validated_head = head(repo)
                if validated_head not in {intent['initial_head'], intent.get('committed'), synchronized_head}:
                    raise LifecycleError('HEAD changed before finish validation')
                precommit = _validate(repo, task['validation'])
                _check_preserved(repo, task)
                if _finish_identity(repo, task_id, branch) != identity or head(repo) != validated_head:
                    raise LifecycleError('HEAD or identity changed during finish validation')
                _operation_check(repo, 'finish validation')
                _check_preserved_plan(task, plan)
                _resolve_files(repo, plan, intent, directory, state)
                _check_preserved(repo, task)
                _checked_paths(repo, plan.get('commit', []), need='source', owner=task_id,
                    completed=set(commit_paths) if synchronized_head and intent.get('committed') else None)
                if _finish_identity(repo, task_id, branch) != identity or head(repo) != validated_head:
                    raise LifecycleError('HEAD or identity changed during finish preservation')
                if _index_paths(repo) - set(commit_paths):
                    raise LifecycleError('validation or cleanup staged unrelated changes')
                if commit_paths and not intent.get('committed'):
                    git(repo, 'add', '--', *commit_paths)
                    if _index_paths(repo) - set(commit_paths):
                        raise LifecycleError('index changed before task commit')
                    if _index_paths(repo):
                        intent['commit_tree'] = git(repo, 'write-tree'); save_state(directory, state)
                        if _finish_identity(repo, task_id, branch) != identity or head(repo) != validated_head:
                            raise LifecycleError('HEAD or identity changed before finish commit')
                        git(repo, 'commit', '-m', message)
                        committed_head = head(repo)
                        parents = (git(repo, 'rev-list', '--parents', '-n', '1', committed_head) or '').split()
                        if parents[1:] != [validated_head] or git(repo, 'rev-parse', committed_head + '^{tree}') != intent['commit_tree']:
                            raise LifecycleError('finish commit identity changed')
                        intent['committed'] = committed_head; save_state(directory, state)
                evidence = _validate(repo, task['validation'])
                _check_preserved(repo, task)
                expected_finish_head = synchronized_head or intent.get('committed') or intent['initial_head']
                if _finish_identity(repo, task_id, branch) != identity or head(repo) != expected_finish_head:
                    raise LifecycleError('HEAD or identity changed during finish validation')
                _operation_check(repo, 'finish validation')
                final_dirty = _snapshot(repo, excluded=_preserved_paths(task))
                if task.get('owner_receipts'):
                    from .producers import owned_dirty_paths
                    owned_outputs = owned_dirty_paths(repo, task)
                    final_dirty = {name: kind for name, kind in final_dirty.items() if name not in owned_outputs}
                waived = _primary_workspace_data(repo, task, final_dirty)
                final_dirty = {name: kind for name, kind in final_dirty.items() if name not in waived}
                if final_dirty:
                    exception = _exception(plan, final_dirty)
                    task['exception'] = exception
                    state['intents'].pop(task_id, None); save_state(directory, state)
                    return {'task': task_id, 'completion': 'exception', 'dirty': sorted(final_dirty)}
                commit = head(repo)
                if _finish_identity(repo, task_id, branch) != identity or commit != expected_finish_head:
                    raise LifecycleError('HEAD or identity changed before finish push')
                pushed = _push(repo, task['preflight'], branch, task['remote'], expected_head=commit)
                task.pop('exception', None)
                task['acceptance'] = {'commit': commit, 'result_ref': result_ref,
                                      'validation': {'precommit': precommit, 'postcommit': evidence},
                                      'push': pushed, 'accepted_at': _now()}
                if synchronized_head:
                    task.setdefault('finish_receipts', []).append(intent.copy())
                if waived:
                    task['acceptance']['waived_workspace_data'] = {
                        'count': len(waived),
                        'sha256': hashlib.sha256('\0'.join(sorted(waived)).encode()).hexdigest()}
                if reclaim_evidence is not None:
                    task['preservation_evidence'] = _bind_preservation_evidence(
                        task.get('preservation_evidence'), reclaim_evidence)
                if users_released:
                    # Save acceptance and last-user release together. A crash
                    # before the callback must not lose the pending request.
                    task['completion_release'] = {'result_ref': result_ref}
                    if task.get('owner_receipts'):
                        task['owner_release'] = {'result_ref': result_ref, 'commit': commit}
                state['intents'].pop(task_id, None); save_state(directory, state)
    integration = _integrate(repo, task_id, result_ref)
    result = {'task': task_id, 'accepted': True, 'commit': commit, 'result_ref': result_ref, 'integration': integration}
    if users_released:
        from .producers import retry as release_producers
        released = release_producers(repo, task_id)
        result['producers'] = released
        if any(not entry.get('reclaimed') for entry in released.get('results', [])):
            return result
        with locked_state(repo) as (_, state):
            remote = _task(state, task_id)['remote']
        control = task_worktree(repo, remote_default(repo, remote))
        retire(control, task=task_id, result_ref=result_ref, users_released=True, request_only=True)
        try:
            result['retirement'] = retire(control, task=task_id, result_ref=result_ref)
        except (LifecycleError, ValueError, OSError) as exc:
            result['retirement'] = {'pending': True, 'reason': str(exc)}
    return result


def _remote_tip(repo, remote, branch):
    rows = (git(repo, 'ls-remote', remote, 'refs/heads/' + branch) or '').splitlines()
    if len(rows) != 1 or rows[0].split()[1:] != ['refs/heads/' + branch]:
        raise LifecycleError('remote integration branch could not be verified')
    return rows[0].split()[0]


def _sync_identity(repo, branch, remote, remote_head, remote_url=None):
    if (current_branch(repo) != branch or _remote_tip(repo, remote, branch) != remote_head
            or (remote_url is not None and git(repo, 'remote', 'get-url', remote) != remote_url)):
        raise LifecycleError('synchronization branch or remote tip changed; preserve and review the pending operation')


def _synchronize(repo, *, branch, remote, expected_head, remote_head, evidence,
                 validation, holder, persist, workspace_record=None):
    """One exact native merge, shared by task repair and integration targets.

    The receipt extends an existing operation; it is never task acceptance.
    Native writers must be quiescent, as for adoption and finish.
    """
    workspace_record = workspace_record or {}
    _check_preserved(repo, workspace_record)
    for marker in ('REBASE_HEAD', 'CHERRY_PICK_HEAD', 'REVERT_HEAD', 'rebase-merge', 'rebase-apply', 'sequencer', 'BISECT_START', 'index.lock'):
        if Path(git(repo, 'rev-parse', '--path-format=absolute', '--git-path', marker)).exists():
            raise LifecycleError('unrelated Git operation prevents synchronization: ' + marker)
    desired = {'branch': branch, 'remote': remote, 'local': expected_head,
               'source': remote_head, 'evidence': evidence,
               'remote_url': git(repo, 'remote', 'get-url', remote)}
    previous = holder.get('synchronization')
    if previous and previous['remote_url'] != desired['remote_url']:
        raise LifecycleError('synchronization remote URL changed')
    if previous and all(previous.get(k) == v for k, v in desired.items()):
        receipt = previous
    else:
        if previous and not previous.get('commit'):
            raise LifecycleError('resume the pending synchronization with its exact local and remote OIDs')
        if head(repo) != expected_head:
            raise LifecycleError('synchronization local HEAD differs from the reviewed OID')
        observed = _remote_tip(repo, remote, branch)
        merge_head = git(repo, 'rev-parse', '--verify', 'MERGE_HEAD', optional=True)
        if observed != remote_head and merge_head != remote_head:
            raise LifecycleError('remote tip differs from the reviewed synchronization source')
        _sync_identity(repo, branch, remote, observed, desired['remote_url'])
        git(repo, 'fetch', remote, 'refs/heads/' + branch)
        if head(repo, 'FETCH_HEAD') != observed:
            raise LifecycleError('remote changed during synchronization fetch')
        if observed != remote_head and git(repo, 'merge-base', '--is-ancestor', remote_head, observed, optional=True) is None:
            raise LifecycleError('manual merge source is not preserved in the actual same-name remote')
        if previous and git(repo, 'merge-base', '--is-ancestor', previous['source'], observed, optional=True) is None:
            raise LifecycleError('remote synchronization history was rewritten')
        if head(repo, expected_head) != expected_head or head(repo, remote_head) != remote_head:
            raise LifecycleError('synchronization requires full commit OIDs')
        if git(repo, 'merge-base', expected_head, remote_head, optional=True) is None:
            raise LifecycleError('synchronization refuses unrelated histories')
        _check_preserved(repo, workspace_record, remote_head)
        merge_head = git(repo, 'rev-parse', '--verify', 'MERGE_HEAD', optional=True)
        if merge_head:
            if merge_head != remote_head:
                raise LifecycleError('manual merge source differs from the exact same-name remote topic')
            dirty = _snapshot(repo, excluded=_preserved_paths(workspace_record))
            if any(code in ('??', '!!') for code in dirty.values()):
                raise LifecycleError('manual merge contains unrelated untracked or private data')
        else:
            _operation_check(repo, 'synchronization')
            if _snapshot(repo, excluded=_preserved_paths(workspace_record)):
                raise LifecycleError('synchronization requires a clean checkout')
        outcome = subprocess.run(['git', '-C', str(repo), 'merge-tree', '--write-tree', '-z', '--name-only', expected_head, remote_head],
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if outcome.returncode not in (0, 1):
            raise LifecycleError('Git could not establish the synchronization merge contract: ' + os.fsdecode(outcome.stderr))
        fields = outcome.stdout.split(b'\0')
        conflicts = []
        for field in fields[1:]:
            if not field: break
            conflicts.append(os.fsdecode(field))
        receipt = {**desired, 'at': _now(), 'expected_tree': os.fsdecode(fields[0]).strip(),
                   'conflicts': conflicts}
        if previous:
            holder.setdefault('synchronization_history', []).append(previous)
        holder['synchronization'] = receipt; persist()
    _check_preserved(repo, workspace_record, remote_head)
    current = head(repo)
    merge_head = git(repo, 'rev-parse', '--verify', 'MERGE_HEAD', optional=True)
    observed_remote = _remote_tip(repo, remote, branch)
    if observed_remote != remote_head:
        git(repo, 'fetch', remote, 'refs/heads/' + branch)
        if head(repo, 'FETCH_HEAD') != observed_remote or git(repo, 'merge-base', '--is-ancestor', remote_head, observed_remote, optional=True) is None:
            raise LifecycleError('pending synchronization remote no longer preserves its pinned source')
    _sync_identity(repo, branch, remote, observed_remote, receipt['remote_url'])
    if receipt.get('commit'):
        if current != receipt['commit'] or merge_head or _snapshot(repo, excluded=_preserved_paths(workspace_record)):
            raise LifecycleError('completed synchronization identity changed')
        return receipt
    if current != expected_head:
        parents = (git(repo, 'rev-list', '--parents', '-1', 'HEAD') or '').split()[1:]
        fast_forward = current == remote_head and git(repo, 'merge-base', '--is-ancestor', expected_head, current, optional=True) is not None
        if merge_head or not (fast_forward or (receipt.get('tree') == git(repo, 'rev-parse', 'HEAD^{tree}')
                                              and parents == [expected_head, remote_head])):
            raise LifecycleError('HEAD changed outside the recorded synchronization')
    elif not merge_head:
        _operation_check(repo, 'synchronization')
        if _snapshot(repo, excluded=_preserved_paths(workspace_record)):
            raise LifecycleError('pending synchronization has unrelated dirty content')
        if git(repo, 'merge-base', '--is-ancestor', remote_head, current, optional=True) is not None:
            pass
        elif git(repo, 'merge-base', '--is-ancestor', current, remote_head, optional=True) is not None:
            # Validate the incoming tree without accepting it. The subsequent
            # validation binds evidence to the actual new checkout.
            git(repo, 'merge', '--ff-only', remote_head)
        else:
            git(repo, 'merge', '--no-ff', '--no-commit', remote_head)
    current = head(repo)
    merge_head = git(repo, 'rev-parse', '--verify', 'MERGE_HEAD', optional=True)
    if merge_head and (current != expected_head or merge_head != remote_head):
        raise LifecycleError('native synchronization merge identity changed')
    _index_protection(repo)
    dirty = _snapshot(repo, excluded=_preserved_paths(workspace_record))
    if any(code in ('??', '!!') or code[1] != ' ' for code in dirty.values()):
        raise LifecycleError('resolve synchronization conflicts and unstaged data in this same checkout')
    tree = git(repo, 'write-tree')
    if merge_head:
        differences = subprocess.run(['git', '-C', str(repo), 'diff', '--name-only', '-z', receipt['expected_tree'], tree],
                                     stdout=subprocess.PIPE, check=True).stdout
        if {os.fsdecode(row) for row in differences.split(b'\0') if row} - set(receipt['conflicts']):
            raise LifecycleError('synchronization index changed outside the recorded conflict paths')
    checked = [_validate(repo, argv) for argv in validation]
    _check_preserved(repo, workspace_record)
    _sync_identity(repo, branch, remote, observed_remote, receipt['remote_url'])
    if head(repo) != current or git(repo, 'write-tree') != tree:
        raise LifecycleError('HEAD or index changed during synchronization validation')
    if git(repo, 'rev-parse', '--verify', 'MERGE_HEAD', optional=True) != merge_head:
        raise LifecycleError('merge state changed during synchronization validation')
    if _snapshot(repo, excluded=_preserved_paths(workspace_record)) != dirty:
        raise LifecycleError('validation changed synchronization working content')
    if merge_head:
        receipt['tree'] = tree; persist()
        git(repo, 'commit', '-m', 'Merge same-name remote branch ' + branch)
        parents = (git(repo, 'rev-list', '--parents', '-1', 'HEAD') or '').split()[1:]
        if parents != [expected_head, remote_head] or git(repo, 'rev-parse', 'HEAD^{tree}') != tree:
            raise LifecycleError('synchronization commit identity changed')
    if _snapshot(repo, excluded=_preserved_paths(workspace_record)):
        raise LifecycleError('synchronization commit left dirty content')
    receipt['commit'] = head(repo); receipt['validation'] = checked; persist()
    _sync_identity(repo, branch, remote, observed_remote, receipt['remote_url'])
    return receipt


def synchronize(repo, *, task, expected_head, remote_head, evidence):
    """Review and resume the same task's same-name remote synchronization."""
    repo = Path(repo).resolve()
    if (not isinstance(evidence, str) or not evidence.strip()
            or not isinstance(expected_head, str) or not isinstance(remote_head, str)
            or not expected_head or not remote_head):
        raise LifecycleError('synchronization requires exact OIDs and durable ownership/review evidence')
    with _lease(repo, task, allow_use=True):
        with locked_state(repo) as (directory, state):
            item = _task(state, task); branch = branch_for_task(repo, task)
            _finish_identity(repo, task, branch)
            if item.get('hold') or item.get('retire'):
                raise LifecycleError('held or retiring task cannot synchronize')
            intent = state['intents'].get(task)
            if intent and intent['kind'] != 'finish':
                raise LifecycleError('resume the existing integration operation with finish')
            holder = intent if intent else item
            if intent:
                previous = intent.get('synchronization', {}).get('commit')
                if expected_head not in {intent.get('committed') or intent['initial_head'], previous}:
                    raise LifecycleError('synchronization must extend the recorded finish HEAD')
                if any(action['phase'] != 'resolved' for action in intent['actions'].values()):
                    raise LifecycleError('finish preservation must complete before synchronization')
            result = _synchronize(repo, branch=branch, remote=item['remote'], expected_head=expected_head,
                remote_head=remote_head, evidence=evidence, validation=[item['validation']],
                holder=holder, persist=lambda: save_state(directory, state), workspace_record=item)
            return {'task': task, 'commit': result['commit'], 'synchronization': result}


def _integrate(repo: Path, task_id: str, result_ref: str) -> dict:
    """Resume only the declared, accepted edge, then follow its parent to default."""
    with locked_state(repo) as (_, state):
        item = _task(state, task_id)
        direction = item['integration']
        target_guard = direction['task'] if direction['kind'] == 'task' else '@default'
    with ExitStack() as stack:
        for identity in sorted({task_id, target_guard}):
            stack.enter_context(_lease(repo, identity, allow_use=identity == task_id))
        with locked_state(repo) as (directory, state):
            item = _task(state, task_id)
            if item.get('hold') or not item.get('acceptance'):
                raise LifecycleError('source is held or not accepted: ' + task_id)
            acceptance = item['acceptance']; source_commit = acceptance['commit']
            source_branch = branch_for_task(repo, task_id)
            if head(repo, 'refs/heads/' + source_branch) != source_commit:
                raise LifecycleError('source HEAD differs from the exact accepted identity')
            for dependency in item['dependencies']:
                required = _task(state, dependency)
                if required.get('hold') or not required.get('acceptance'):
                    raise LifecycleError('dependency is held or not accepted: ' + dependency)
                if head(repo, 'refs/heads/' + branch_for_task(repo, dependency)) != required['acceptance']['commit']:
                    raise LifecycleError('dependency changed after acceptance: ' + dependency)
            parent = None
            if direction['kind'] == 'task':
                parent = _task(state, direction['task'])
                if parent.get('hold') or not parent.get('acceptance'):
                    raise LifecycleError('integration parent is held or not accepted: ' + direction['task'])
                target_branch = branch_for_task(repo, direction['task'])
            else:
                target_branch = remote_default(repo, item['remote'])
            target_worktree = task_worktree(repo, target_branch)
            _check_preserved(task_worktree(repo, source_branch), item)
            _check_preserved(target_worktree, parent or {}, source_commit)
            if current_branch(target_worktree) != target_branch:
                raise LifecycleError('integration checkout branch changed')
            record = item.get('integrated')
            if record and record['source'] == source_commit:
                if git(repo, 'merge-base', '--is-ancestor', record['commit'], head(target_worktree), optional=True) is None:
                    raise LifecycleError('recorded integration is no longer in its target')
                merged = record['commit']
            else:
                intent = state['intents'].get(task_id)
                if intent and (intent['kind'] != 'merge' or intent['source'] != source_commit
                               or intent['target'] != target_branch):
                    raise LifecycleError('pending integration identity differs; preserve the existing operation')
                if not intent:
                    holder = item.get('integration_synchronization', {})
                    pending = holder.get('synchronization')
                    if pending and pending.get('commit') == head(target_worktree):
                        # The exact prior synchronization is already complete.
                        target_head = pending['commit']
                    elif pending and not pending.get('commit'):
                        target_head = pending['local']
                    else:
                        if _snapshot(target_worktree, excluded=_preserved_paths(parent or {})) or git(target_worktree, 'rev-parse', '--verify', 'MERGE_HEAD', optional=True):
                            raise LifecycleError('integration target has unrelated dirty or merge state')
                        target_head = head(target_worktree)
                        if parent and target_head != parent['acceptance']['commit']:
                            raise LifecycleError('parent HEAD differs from its accepted identity')
                    remote_head = _remote_tip(repo, item['remote'], target_branch)
                    if target_head != remote_head or (pending and not pending.get('commit')):
                        synced = _synchronize(target_worktree, branch=target_branch, remote=item['remote'],
                            expected_head=pending['local'] if pending and not pending.get('commit') else target_head,
                            remote_head=pending['source'] if pending and not pending.get('commit') else remote_head,
                            evidence=result_ref,
                            validation=[parent['validation']] if parent else [],
                            holder=item.setdefault('integration_synchronization', {}),
                            persist=lambda: save_state(directory, state), workspace_record=parent)
                        target_head = synced['commit']
                        remote_head = _remote_tip(repo, item['remote'], target_branch)
                        if synced['source'] != remote_head:
                            synced = _synchronize(target_worktree, branch=target_branch, remote=item['remote'],
                                expected_head=target_head, remote_head=remote_head, evidence=result_ref,
                                validation=[parent['validation']] if parent else [],
                                holder=item['integration_synchronization'],
                                persist=lambda: save_state(directory, state), workspace_record=parent)
                            target_head = synced['commit']
                    intent = {'kind': 'merge', 'source': source_commit, 'target': target_branch,
                              'target_head': target_head, 'result_ref': result_ref, 'at': _now()}
                    state['intents'][task_id] = intent; save_state(directory, state)
                pending_sync = intent.get('synchronization')
                if pending_sync and not pending_sync.get('commit'):
                    _synchronize(target_worktree, branch=target_branch, remote=item['remote'],
                        expected_head=pending_sync['local'], remote_head=pending_sync['source'],
                        evidence=result_ref, validation=[item['validation']] + ([parent['validation']] if parent else []),
                        holder=intent, persist=lambda: save_state(directory, state), workspace_record=parent)
                current = head(target_worktree)
                merge_head = git(target_worktree, 'rev-parse', '--verify', 'MERGE_HEAD', optional=True)
                if current == intent.get('synchronization', {}).get('commit'):
                    pass
                elif current != intent['target_head']:
                    parents = (git(target_worktree, 'rev-list', '--parents', '-n', '1', 'HEAD') or '').split()[1:]
                    if merge_head or parents != [intent['target_head'], source_commit]:
                        raise LifecycleError('target moved outside the recorded normal merge')
                    intent['merged'] = current; save_state(directory, state)
                elif not merge_head:
                    if _snapshot(target_worktree, excluded=_preserved_paths(parent or {})):
                        raise LifecycleError('pending target has unrelated dirty content')
                    if git(repo, 'merge-base', '--is-ancestor', source_commit, current, optional=True) is not None:
                        intent['merged'] = current
                    else:
                        git(target_worktree, 'merge', '--no-ff', '--no-commit', source_commit)
                        merge_head = git(target_worktree, 'rev-parse', '--verify', 'MERGE_HEAD', optional=True)
                if not intent.get('merged'):
                    if merge_head != source_commit:
                        raise LifecycleError('native merge identity differs from the requested source')
                    _index_protection(target_worktree)
                # Both the child and its parent contract must hold for the new
                # parent identity before it can progress to the next edge.
                checked_head = head(target_worktree)
                checked_tree = git(target_worktree, 'write-tree')
                evidence = _validate(target_worktree, item['validation'])
                parent_evidence = _validate(target_worktree, parent['validation']) if parent else None
                _check_preserved(target_worktree, parent or {})
                if head(target_worktree) != checked_head or git(target_worktree, 'write-tree') != checked_tree:
                    raise LifecycleError('integration HEAD or index changed during validation')
                if git(target_worktree, 'rev-parse', '--verify', 'MERGE_HEAD', optional=True) != merge_head:
                    raise LifecycleError('integration merge state changed during validation')
                dirty = _snapshot(target_worktree, excluded=_preserved_paths(parent or {}))
                if any(code in ('??', '!!') or code[1] != ' ' for code in dirty.values()):
                    raise LifecycleError('merge validation left unstaged or private data; resolve in this target')
                if not intent.get('merged'):
                    intent['merge_tree'] = git(target_worktree, 'write-tree'); save_state(directory, state)
                    git(target_worktree, 'commit', '-m', 'Merge workspace task ' + task_id)
                    committed = head(target_worktree)
                    parents = (git(target_worktree, 'rev-list', '--parents', '-1', committed) or '').split()[1:]
                    if parents != [checked_head, source_commit] or git(target_worktree, 'rev-parse', 'HEAD^{tree}') != checked_tree:
                        raise LifecycleError('integration commit changed from the validated merge')
                    intent['merged'] = committed; save_state(directory, state)
                if _snapshot(target_worktree, excluded=_preserved_paths(parent or {})):
                    raise LifecycleError('integration commit left dirty content')
                merged = intent.get('synchronization', {}).get('commit') or intent['merged']
                remote_head = _remote_tip(repo, item['remote'], target_branch)
                pending_sync = intent.get('synchronization')
                if remote_head != merged or (pending_sync and not pending_sync.get('commit')):
                    git(repo, 'fetch', item['remote'], 'refs/heads/' + target_branch)
                    if git(repo, 'merge-base', '--is-ancestor', remote_head, merged, optional=True) is None or (pending_sync and not pending_sync.get('commit')):
                        synced = _synchronize(target_worktree, branch=target_branch, remote=item['remote'],
                            expected_head=pending_sync['local'] if pending_sync and not pending_sync.get('commit') else merged,
                            remote_head=pending_sync['source'] if pending_sync and not pending_sync.get('commit') else remote_head,
                            evidence=result_ref, validation=[item['validation']] + ([parent['validation']] if parent else []),
                            holder=intent, persist=lambda: save_state(directory, state), workspace_record=parent)
                        merged = synced['commit']
                evidence = _validate(target_worktree, item['validation'])
                parent_evidence = _validate(target_worktree, parent['validation']) if parent else None
                _check_preserved(target_worktree, parent or {})
                if head(target_worktree) != merged or _snapshot(target_worktree, excluded=_preserved_paths(parent or {})):
                    raise LifecycleError('integration changed during final validation')
                pushed = _push(target_worktree, item['preflight'], target_branch, item['remote'], expected_head=merged)
                record = {'destination': target_branch, 'commit': merged, 'source': source_commit,
                          'validation': evidence, 'push': pushed, 'result_ref': result_ref, 'at': _now()}
                item['integrated'] = record
                if parent:
                    parent['acceptance'] = {**parent['acceptance'], 'commit': merged,
                        'previous_accepted': parent['acceptance']['commit'],
                        'child_integration': {'task': task_id, 'source': source_commit},
                        'validation': parent_evidence, 'push': pushed, 'accepted_at': _now()}
                state['intents'].pop(task_id, None); save_state(directory, state)
    result = {'destination': target_branch, 'commit': merged}
    if direction['kind'] == 'task':
        result['parent'] = _integrate(repo, direction['task'], result_ref)
    return result


def _retirement_contents(workspace):
    """Validate preexisting content before the no-delete retirement boundary."""
    _index_protection(workspace)
    snapshot = _snapshot(workspace)
    if any(code != '!!' for code in snapshot.values()) or git(workspace, 'submodule', 'status', '--recursive'):
        raise LifecycleError('retire refuses dirty, untracked, ignored, or submodule data')
    process = subprocess.run(['git', '-C', str(workspace), 'ls-files', '-z'], capture_output=True, check=True)
    tracked = {os.fsdecode(row) for row in process.stdout.split(b'\0') if row}
    directories = {str(parent).replace(os.sep, '/') for name in tracked for parent in Path(name).parents if str(parent) != '.'}
    empty_directories = set()
    def walk_error(error):
        raise error
    for current, dirs, files in os.walk(workspace, topdown=True, followlinks=False, onerror=walk_error):
        relative = Path(current).relative_to(workspace)
        for name in [*dirs, *files]:
            path = Path(current) / name; logical = (relative / name).as_posix()
            _no_links(path, workspace)
            info = path.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400):
                raise LifecycleError('retire refuses links or reparse points')
            if logical == '.git':
                if not stat.S_ISREG(info.st_mode):
                    raise LifecycleError('only linked worktrees can retire')
                continue
            if os.path.ismount(path):
                raise LifecycleError('retire refuses linked or mounted filesystem content')
            if stat.S_ISDIR(info.st_mode):
                if logical not in directories:
                    empty_directories.add(logical)
            elif logical not in tracked or not stat.S_ISREG(info.st_mode):
                raise LifecycleError('retire refuses nontracked or special filesystem content')
    # An ignored Git entry is admissible only when this filesystem walk proved
    # it is an unowned directory tree containing no files or protected objects.
    if any(name.rstrip('/') not in empty_directories for name in snapshot):
        raise LifecycleError('retire refuses ignored filesystem content')


def _retirement_identity(path):
    _no_links(path)
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or os.path.ismount(path):
        raise LifecycleError('retirement directory identity changed')
    return [info.st_dev, info.st_ino]


def _retirement_admin(workspace, common):
    admin = Path(git(workspace, 'rev-parse', '--path-format=absolute', '--git-dir')).resolve()
    admin_root = Path(git(workspace, 'rev-parse', '--path-format=absolute', '--git-path', 'worktrees')).resolve()
    if admin.parent != admin_root or admin_root.parent != common or admin == common:
        raise LifecycleError('target is not an exact linked worktree admin entry')
    if Path(git(workspace, 'rev-parse', '--path-format=absolute', '--git-common-dir')).resolve() != common:
        raise LifecycleError('retirement Git common directory changed')
    return admin


def _retirement_pointer(payload, admin_original, admin_at):
    for path in (payload / '.git', admin_at / 'gitdir'):
        _no_links(path)
        if not stat.S_ISREG(path.lstat().st_mode):
            raise LifecycleError('retirement Git pointer is not a regular file')
    pointer = (payload / '.git').read_text(encoding='utf-8').strip()
    if not pointer.startswith('gitdir: '):
        raise LifecycleError('retirement payload Git pointer changed')
    value = Path(pointer[len('gitdir: '):])
    if not value.is_absolute():
        value = payload / value
    if value.resolve() != admin_original:
        raise LifecycleError('retirement payload Git pointer changed')
    gitdir = (admin_at / 'gitdir').read_text(encoding='utf-8').strip()
    value = Path(gitdir)
    if not value.is_absolute():
        value = admin_original / value
    if value.resolve() != (payload / '.git').resolve():
        raise LifecycleError('retirement admin Git pointer changed')


def _retirement_record(records, path):
    return [row for row in records if Path(row['worktree']) == path]


@contextmanager
def _retirement_transaction(repo, task):
    """Task lease is held by caller; Git and filesystem work need no global lock."""
    from copy import deepcopy
    sections = ('tasks', 'retired', 'intents')
    with locked_state(repo) as (directory, state):
        working = deepcopy(state)
    expected = {section: deepcopy(state.get(section, {}).get(task)) for section in sections}

    def persist():
        nonlocal expected
        with locked_state(repo) as (_, latest):
            if any(latest.get(section, {}).get(task) != expected[section] for section in sections):
                raise LifecycleError('retirement task changed concurrently; preserve the request')
            for name, other in latest['tasks'].items():
                if name != task and (task in other['dependencies'] or other['integration'].get('task') == task):
                    raise LifecycleError('another task still depends on this identity: ' + name)
            for section in sections:
                value = working.get(section, {}).get(task)
                if value is None:
                    latest.setdefault(section, {}).pop(task, None)
                else:
                    latest.setdefault(section, {})[task] = deepcopy(value)
            save_state(directory, latest)
        expected = {section: deepcopy(working.get(section, {}).get(task)) for section in sections}

    yield directory, working, persist


def retire(repo, *, task: str, result_ref: str, users_released: bool = False, request_only: bool = False, preservation_evidence: str | None = None) -> dict:
    """End one active worktree while retaining its payload and Git admin entry."""
    repo = Path(repo).resolve()
    incoming = _durable_preservation_evidence(preservation_evidence)
    if users_released:
        owner_pending = False
        with _lease(repo, task, allow_use=request_only):
            with locked_state(repo) as (directory, state):
                item = state['tasks'].get(task)
                if item and item.get('adoption', {}).get('preserved_data'):
                    raise LifecycleError('checkout with foreign preserved data cannot retire')
                if item and item.get('owner_receipts'):
                    acceptance = item.get('acceptance')
                    if item.get('hold') or not acceptance or acceptance['result_ref'] != result_ref:
                        raise LifecycleError('retire requires exact accepted result and no hold')
                    evidence = _bind_preservation_evidence(item.get('preservation_evidence'), incoming)
                    if evidence:
                        item['preservation_evidence'] = evidence
                    item['completion_release'] = {'result_ref': result_ref}
                    item['owner_release'] = {'result_ref': result_ref, 'commit': acceptance['commit']}
                    save_state(directory, state)
                    owner_pending = any(record.get('phase') != 'completed' for record in item['owner_receipts'].values())
        if owner_pending:
            if request_only:
                return {'task': task, 'pending': True}
            from .producers import retry as release_producers
            released = release_producers(repo, task)
            if any(not entry.get('reclaimed') for entry in released['results']):
                return {'task': task, 'retired': False, 'pending': True, 'producers': released}
    with _lease(repo, task, allow_use=request_only):
        with _retirement_transaction(repo, task) as (directory, state, persist):
            if task in state.get('retired', {}):
                result = {'task': task, 'retired': True, 'receipt': state['retired'][task]}
            else:
                item = _task(state, task); request = item.get('retire')
                if item.get('adoption', {}).get('preserved_data'):
                    raise LifecycleError('checkout with foreign preserved data cannot retire')
                acceptance = item.get('acceptance')
                if item.get('hold') or not acceptance or acceptance.get('result_ref') != result_ref:
                    raise LifecycleError('retire requires exact accepted result and no hold')
                if any(record.get('phase') != 'completed' for record in item.get('owner_receipts', {}).values()):
                    raise LifecycleError('retire waits for exact producer generations to finish reclaiming')
                if not request and not users_released:
                    raise LifecycleError('retire requires explicit external-user release')
                for other_id, other in state['tasks'].items():
                    if other_id != task and (task in other['dependencies'] or other['integration'].get('task') == task):
                        raise LifecycleError('another task still depends on this identity: ' + other_id)
                expected = acceptance['commit']
                integrated = item.get('integrated')
                if not integrated or integrated['source'] != expected:
                    raise LifecycleError('retire requires exact accepted integration')
                if not request:
                    default = remote_default(repo, item['remote'])
                    remote_tip = _remote_tip(repo, item['remote'], default)
                    git(repo, 'fetch', '--no-write-fetch-head', item['remote'], remote_tip)
                    if git(repo, 'merge-base', '--is-ancestor', expected, remote_tip, optional=True) is None:
                        raise LifecycleError('accepted source has not reached the actual remote default')
                branch = request['branch'] if request else branch_for_task(repo, task)
                if head(repo, 'refs/heads/' + branch) != expected:
                    raise LifecycleError('retire expected accepted HEAD; branch changed')
                workspace = Path(request['path']) if request else task_worktree(repo, branch)
                if workspace == Path(worktree_records(repo)[0]['worktree']).resolve():
                    raise LifecycleError('primary checkout cannot retire')
                if not request_only and (repo == workspace or workspace in repo.parents or Path.cwd() == workspace or workspace in Path.cwd().parents):
                    raise LifecycleError('retire must run outside its target worktree')
                for dependency in (Path(__file__).resolve(), Path(os.sys.executable).resolve()):
                    if workspace == dependency or workspace in dependency.parents:
                        raise LifecycleError('retire target supplies this lifecycle runtime')
                if not request:
                    identity = _retirement_identity(workspace)
                    common = directory.parent
                    admin = _retirement_admin(workspace, common)
                    admin_identity = _retirement_identity(admin)
                    _retirement_pointer(workspace, admin, admin)
                    token = uuid.uuid4().hex
                    recovery_root = workspace.parent / '.workspace-lifecycle-recovery'
                    if os.path.lexists(recovery_root):
                        _no_links(recovery_root)
                        if _retirement_identity(recovery_root)[0] != identity[0]:
                            raise LifecycleError('recovery payload root is on another filesystem')
                    else:
                        recovery_root.mkdir()
                    recovery = recovery_root / token
                    if os.path.lexists(recovery):
                        raise LifecycleError('recovery payload destination already exists')
                    admin_root = directory / 'recovery-admin'
                    if os.path.lexists(admin_root):
                        _no_links(admin_root)
                    else:
                        admin_root.mkdir()
                    admin_slot = admin_root / token
                    admin_slot.mkdir()
                    if _retirement_identity(admin_slot)[0] != admin_identity[0]:
                        raise LifecycleError('recovery admin is on another filesystem')
                    bound = _bind_preservation_evidence(item.get('preservation_evidence'), incoming)
                    request = {'branch': branch, 'path': str(workspace), 'identity': identity,
                               'recovery_path': str(recovery), 'recovery_identity': identity,
                               'recovery_root': str(recovery_root), 'recovery_root_identity': _retirement_identity(recovery_root),
                               'admin_original_path': str(admin), 'admin_identity': admin_identity,
                               'admin_archive_path': str(admin_slot / 'admin'), 'admin_slot_identity': _retirement_identity(admin_slot),
                               'expected_head': expected, 'result_ref': result_ref,
                               'users_released': True, 'phase': 'requested', 'at': _now()}
                    if bound:
                        request['preservation_evidence'] = bound
                    item.pop('preservation_evidence', None)
                    item['retire'] = request; persist()
                else:
                    bound = _bind_preservation_evidence(request.get('preservation_evidence') or item.get('preservation_evidence'), incoming)
                    if bound and request.get('preservation_evidence') != bound:
                        request['preservation_evidence'] = bound
                        item.pop('preservation_evidence', None)
                        persist()
                    elif bound and 'preservation_evidence' in item:
                        item.pop('preservation_evidence', None)
                        persist()
                if request_only:
                    return {'task': task, 'pending': True}
                recovery = Path(request['recovery_path'])
                admin = Path(request['admin_original_path'])
                archive = Path(request['admin_archive_path'])
                if (request['expected_head'] != expected or request['result_ref'] != result_ref
                        or not request['users_released']):
                    raise LifecycleError('retirement request identity changed')
                if _retirement_identity(Path(request['recovery_root'])) != request['recovery_root_identity']:
                    raise LifecycleError('recovery payload root identity changed')
                if _retirement_identity(archive.parent) != request['admin_slot_identity']:
                    raise LifecycleError('recovery admin slot identity changed')
                if os.path.lexists(recovery):
                    if _retirement_identity(recovery) != request['recovery_identity']:
                        raise LifecycleError('recovery payload identity changed')
                    if os.path.lexists(admin) and os.path.lexists(archive):
                        raise LifecycleError('both active and archived admin entries exist')
                else:
                    if request['phase'] not in ('requested', 'moving') or os.path.lexists(archive):
                        raise LifecycleError('recovery payload disappeared before retirement completed')
                    if _retirement_identity(workspace) != request['identity']:
                        raise LifecycleError('retirement filesystem identity changed')
                    records = worktree_records(repo)
                    found = _retirement_record(records, workspace)
                    if len(found) != 1 or found[0].get('branch') != 'refs/heads/' + branch or head(workspace) != expected:
                        raise LifecycleError('retirement Git identity changed')
                    if _retirement_admin(workspace, directory.parent) != admin or _retirement_identity(admin) != request['admin_identity']:
                        raise LifecycleError('retirement admin identity changed')
                    _retirement_pointer(workspace, admin, admin)
                    if request['phase'] == 'requested':
                        _retirement_contents(workspace)
                        request['phase'] = 'moving'; persist()
                    git(repo, 'worktree', 'move', str(workspace), str(recovery))
                if _retirement_identity(recovery) != request['recovery_identity']:
                    raise LifecycleError('recovery payload identity changed')
                if os.path.lexists(admin):
                    if _retirement_identity(admin) != request['admin_identity']:
                        raise LifecycleError('retirement admin identity changed')
                    found = _retirement_record(worktree_records(repo), recovery)
                    if len(found) != 1 or found[0].get('branch') != 'refs/heads/' + branch or head(recovery) != expected:
                        raise LifecycleError('recovery Git identity changed')
                    _retirement_pointer(recovery, admin, admin)
                    if request['phase'] != 'recovery-held':
                        request['phase'] = 'recovery-held'; persist()
                    if os.path.lexists(archive):
                        raise LifecycleError('admin archive destination already exists')
                    request['phase'] = 'archiving-admin'; persist()
                    admin.rename(archive)
                elif not os.path.lexists(archive):
                    raise LifecycleError('retirement admin entry disappeared without archive')
                if _retirement_identity(recovery) != request['recovery_identity'] or _retirement_identity(archive) != request['admin_identity']:
                    raise LifecycleError('retirement archive identity changed')
                _retirement_pointer(recovery, admin, archive)
                records = worktree_records(repo)
                if _retirement_record(records, recovery) or _retirement_record(records, workspace):
                    raise LifecycleError('target remains registered as an active Git worktree')
                if head(repo, 'refs/heads/' + branch) != expected:
                    raise LifecycleError('retired branch was not preserved')
                binding = git(repo, 'config', '--local', '--get', 'branch.' + branch + '.workspaceTask', optional=True)
                if binding not in (None, task):
                    raise LifecycleError('retired branch binding changed')
                if binding:
                    git(repo, 'config', '--local', '--unset', 'branch.' + branch + '.workspaceTask')
                from . import reclamation
                content_manifest = _tree_manifest(recovery)
                admin_manifest = _tree_manifest(archive)
                receipt = {'commit': expected, 'result_ref': result_ref,
                    'branch': branch, 'remote': item['remote'], 'phase': 'retired',
                    'users_released': request['users_released'],
                    'removed_from_active_at': _now(), 'recovery_path': str(recovery),
                    'original_identity': request['identity'], 'recovery_identity': request['recovery_identity'],
                    'admin_original_path': str(admin), 'admin_archive_path': str(archive),
                    'admin_identity': request['admin_identity'],
                    'original_path': str(workspace), 'recovery_held': True,
                    'content_manifest': content_manifest,
                    'admin_manifest': admin_manifest,
                    'manifest_id': hashlib.sha256(json.dumps(
                        [content_manifest, admin_manifest], separators=(',', ':'),
                        ensure_ascii=True).encode()).hexdigest(),
                    'payload_progress': reclamation.capture(recovery, content_manifest, request['recovery_identity']),
                    'admin_progress': reclamation.capture(archive, admin_manifest, request['admin_identity'])}
                if item.get('finish_receipts'):
                    receipt['finish_receipts'] = item['finish_receipts']
                if request.get('preservation_evidence'):
                    receipt['preservation_evidence'] = request['preservation_evidence']
                    receipt['reclaim_phase'] = 'requested'
                state.setdefault('retired', {})[task] = receipt
                del state['tasks'][task]
                state['intents'].pop(task, None); persist()
                result = {'task': task, 'retired': True, 'branch': branch, 'receipt': receipt}
    if request_only:
        return result
    evidence = result['receipt'].get('preservation_evidence')
    if evidence:
        try:
            reclaimed = reclaim(repo, task=task, result_ref=result_ref, preservation_evidence=evidence)
            result['reclaim'] = reclaimed
            result['receipt'] = reclaimed['receipt']
        except (LifecycleError, ValueError, OSError, subprocess.CalledProcessError) as exc:
            with locked_state(repo) as (_, state):
                result['receipt'] = state['retired'][task]
            result['reclaim'] = {'task': task, 'reclaimed': False, 'error': str(exc)}
    return result



def _tree_manifest(root: Path):
    """Hash one ordinary directory tree. Refuse links, mounts, and nested Git."""
    root = Path(root)
    _no_links(root)
    info = root.lstat()
    if not stat.S_ISDIR(info.st_mode) or os.path.ismount(root):
        raise LifecycleError('reclaim target is not an ordinary directory')
    rows = []

    def walk_error(error):
        raise LifecycleError('reclaim cannot read ' + str(error.filename)) from error

    for current, dirs, files in os.walk(root, topdown=True, followlinks=False, onerror=walk_error):
        relative = Path(current).relative_to(root)
        for name in list(dirs):
            path = Path(current) / name
            logical = (relative / name).as_posix()
            _no_links(path, root)
            child = path.lstat()
            if os.path.ismount(path) or not stat.S_ISDIR(child.st_mode):
                raise LifecycleError('reclaim refuses a mount or non-directory')
            if name == '.git':
                raise LifecycleError('reclaim refuses a nested repository')
            rows.append([logical, 'dir', ''])
        for name in files:
            path = Path(current) / name
            logical = (relative / name).as_posix()
            _no_links(path, root)
            child = path.lstat()
            if logical != '.git' and name == '.git':
                raise LifecycleError('reclaim refuses a nested repository')
            if not stat.S_ISREG(child.st_mode):
                raise LifecycleError('reclaim refuses a special file')
            rows.append([logical, 'file', _sha(path)])
    rows.sort()
    return rows


def reclaim(repo, *, task: str, result_ref: str, preservation_evidence: str) -> dict:
    """Replay one exact retirement receipt under a task lease, not the state lock."""
    from copy import deepcopy
    from . import reclamation

    repo = Path(repo).resolve()
    preservation_evidence = _durable_preservation_evidence(preservation_evidence)
    if preservation_evidence is None:
        raise LifecycleError('reclaim requires durable preservation evidence')
    with _lease(repo, task):
        with locked_state(repo) as (_, state):
            if task in state.get('tasks', {}):
                raise LifecycleError('reclaim refuses an active or in-flight retirement')
            receipt = deepcopy(state.get('retired', {}).get(task))
        if not receipt:
            raise LifecycleError('reclaim requires a retired receipt')
        if receipt.get('result_ref') != result_ref:
            raise LifecycleError('reclaim result reference does not match the retired receipt')
        if receipt.get('reclaim_phase') == 'reclaimed':
            return {'task': task, 'reclaimed': True, 'receipt': receipt}
        expected = deepcopy(receipt)

        def persist():
            # Re-read the common state and replace only this task's receipt.
            # Never publish a snapshot captured before another task's update.
            nonlocal expected
            with locked_state(repo) as (directory, latest):
                if task in latest.get('tasks', {}) or latest.get('retired', {}).get(task) != expected:
                    raise LifecycleError('reclaim receipt changed concurrently; holding payload')
                latest['retired'][task] = deepcopy(receipt)
                save_state(directory, latest)
            expected = deepcopy(receipt)

        stored = receipt.get('preservation_evidence')
        if stored and stored != preservation_evidence:
            raise LifecycleError('reclaim preservation evidence changed')
        receipt['preservation_evidence'] = preservation_evidence
        if not receipt.get('reclaim_phase'):
            receipt['reclaim_phase'] = 'requested'
        # Evidence and the pending request become durable together, including
        # explicit late-evidence reclamation. A fetch failure cannot lose it.
        persist()
        try:
            if not receipt.get('users_released'):
                raise LifecycleError('reclaim requires released external users')
            if not receipt.get('content_manifest') or not receipt.get('admin_manifest') or not receipt.get('remote'):
                raise LifecycleError('reclaim holds a receipt without a retirement content manifest')
            manifest_id = hashlib.sha256(json.dumps(
                [receipt['content_manifest'], receipt['admin_manifest']],
                separators=(',', ':'), ensure_ascii=True).encode()).hexdigest()
            if receipt.get('manifest_id', manifest_id) != manifest_id:
                raise LifecycleError('retirement manifest identity changed')
            receipt['manifest_id'] = manifest_id
            default = remote_default(repo, receipt['remote'])
            remote_head = _remote_tip(repo, receipt['remote'], default)
            # FETCH_HEAD is shared among tasks. Test ancestry against the exact
            # observed remote object instead of a mutable fetch side effect.
            git(repo, 'fetch', '--no-write-fetch-head', receipt['remote'], remote_head)
            if git(repo, 'merge-base', '--is-ancestor', receipt['commit'], remote_head, optional=True) is None:
                raise LifecycleError('retired commit is no longer on the remote default')
            recovery = Path(receipt['recovery_path'])
            archive = Path(receipt['admin_archive_path'])
            phase = receipt['reclaim_phase']
            if phase in ('requested', 'authorized'):
                staging = Path(receipt.get('reclaim_staging', str(recovery.parent / (recovery.name + '.reclaim'))))
                if phase == 'requested':
                    if os.path.lexists(staging):
                        raise LifecycleError('reclaim staging path already exists')
                    if not os.path.lexists(recovery):
                        raise LifecycleError('recovery payload disappeared before reclaim')
                    payload = reclamation.capture(recovery, receipt['content_manifest'], receipt['recovery_identity'])
                    admin = reclamation.capture(archive, receipt['admin_manifest'], receipt['admin_identity'])
                    # New retirement receipts retain member identities. A legacy
                    # receipt is bound to its original manifest before any intent.
                    for key, snapshot in (('payload_progress', payload), ('admin_progress', admin)):
                        if key in receipt and receipt[key] != snapshot:
                            raise LifecycleError('recovery content identity changed after retirement; holding payload')
                        receipt[key] = snapshot
                    receipt['reclaim_staging'] = str(staging)
                    receipt['reclaim_phase'] = 'authorized'
                    persist()
                if os.path.lexists(recovery) and not os.path.lexists(staging):
                    if _retirement_identity(recovery) != receipt['recovery_identity']:
                        raise LifecycleError('recovery payload identity changed')
                    if _tree_manifest(recovery) != receipt['content_manifest']:
                        raise LifecycleError('recovery content changed after retirement; holding payload')
                    recovery.rename(staging)
                    if os.name != 'nt':
                        parent_fd = os.open(staging.parent, os.O_RDONLY | os.O_DIRECTORY)
                        try: os.fsync(parent_fd)
                        finally: os.close(parent_fd)
                elif os.path.lexists(recovery) or not os.path.lexists(staging):
                    raise LifecycleError('reclaim staging does not match the authorized receipt')
                if _retirement_identity(staging) != receipt['recovery_identity']:
                    raise LifecycleError('reclaim staging identity changed')
                if _tree_manifest(staging) != receipt['content_manifest']:
                    raise LifecycleError('recovery content changed after rename; holding payload')
                # Receipts interrupted by the earlier implementation may have an
                # authorization but no per-member snapshot yet. Capture only
                # while the original complete manifest can still be proved.
                if 'payload_progress' not in receipt:
                    receipt['payload_progress'] = reclamation.capture(staging, receipt['content_manifest'], receipt['recovery_identity'])
                if 'admin_progress' not in receipt:
                    receipt['admin_progress'] = reclamation.capture(archive, receipt['admin_manifest'], receipt['admin_identity'])
                receipt['reclaim_phase'] = 'renamed'
                persist()
                phase = 'renamed'
            if phase == 'renamed':
                staging = Path(receipt['reclaim_staging'])
                if 'payload_progress' not in receipt:
                    receipt['payload_progress'] = reclamation.capture(staging, receipt['content_manifest'], receipt['recovery_identity'])
                    persist()
                reclamation.remove_tree(staging, receipt['content_manifest'], receipt['recovery_identity'], receipt['payload_progress'], persist)
                receipt['reclaim_phase'] = 'payload-removed'
                persist()
                phase = 'payload-removed'
            if phase in ('payload-removed', 'admin-removing'):
                if 'admin_progress' not in receipt:
                    receipt['admin_progress'] = reclamation.capture(archive, receipt['admin_manifest'], receipt['admin_identity'])
                receipt['reclaim_phase'] = 'admin-removing'
                persist()
                reclamation.remove_tree(archive, receipt['admin_manifest'], receipt['admin_identity'], receipt['admin_progress'], persist)
                receipt['reclaim_phase'] = 'admin-removed'
                persist()
                phase = 'admin-removed'
            if phase != 'admin-removed':
                raise LifecycleError('unknown reclaim phase; holding payload')
            receipt['phase'] = 'reclaimed'
            receipt['recovery_held'] = False
            receipt['reclaim_phase'] = 'reclaimed'
            receipt['reclaimed_at'] = _now()
            receipt.pop('reclaim_failure', None)
            persist()
            return {'task': task, 'reclaimed': True, 'receipt': receipt}
        except (LifecycleError, OSError, subprocess.CalledProcessError) as exc:
            receipt['reclaim_failure'] = {
                'reason': str(exc), 'at': _now(),
                'next_action': 'Release conflicting use or repair the recorded identity; retry the same reclaim request. Never replace its manifest.',
            }
            # Saving the failure is best effort; the already durable request and
            # intent remain authoritative if the storage failure also persists.
            try: persist()
            except (LifecycleError, OSError): pass
            raise


def reclaim_pending(repo, task: str | None = None) -> dict:
    """Resume reclaim that already has preservation evidence. Never authorize a new one."""
    repo = Path(repo).resolve()
    with locked_state(repo) as (_, state):
        pending = [(name, item['result_ref'], item['preservation_evidence'])
                   for name, item in state.get('retired', {}).items()
                   if task is None or name == task
                   if item.get('preservation_evidence') and item.get('reclaim_phase') not in (None, 'reclaimed')]
    results = []
    for name, reference, evidence in pending:
        try:
            results.append(reclaim(repo, task=name, result_ref=reference, preservation_evidence=evidence))
        except (LifecycleError, ValueError, OSError, subprocess.CalledProcessError) as exc:
            results.append({'task': name, 'reclaimed': False, 'error': str(exc)})
    return {'pending': results}


def retire_pending(repo, task: str | None = None) -> dict:
    """Retry only durable explicit retirement requests, never scan for cleanup."""
    repo = Path(repo).resolve()
    with locked_state(repo) as (_, state):
        pending = [(name, (item.get('retire') or item.get('completion_release'))['result_ref'], bool(item.get('retire')))
                   for name, item in state['tasks'].items()
                   if task is None or name == task
                   if item.get('retire') or item.get('completion_release')]
    results = []
    for name, reference, requested in pending:
        try:
            if requested:
                results.append(retire(repo, task=name, result_ref=reference))
            else:
                # Integration rechecks exact accepted identities and resumes its
                # existing intent. It cannot create acceptance for new work.
                _integrate(repo, name, reference)
                from .producers import retry as release_producers
                released = release_producers(repo, name)
                if any(not entry.get('reclaimed') for entry in released.get('results', [])):
                    results.append({'task': name, 'retired': False, 'producers': released,
                                    'error': 'producer reclamation remains pending'})
                    continue
                results.append(retire(repo, task=name, result_ref=reference, users_released=True))
        except (LifecycleError, ValueError, OSError, subprocess.CalledProcessError) as exc:
            results.append({'task': name, 'retired': False, 'error': str(exc)})
    return {'pending': results}


def check_run_identity(repo, task: str) -> None:
    if bound_task(repo) != task or task_worktree(repo, branch_for_task(repo, task)) != top(repo):
        raise LifecycleError('run must use the exact bound task checkout')


def before_run(repo, task: str, cwd=None) -> None:
    with locked_state(repo) as (_, state):
        item = _task(state, task)
        _check_preserved(repo, item)
        if cwd is not None:
            _check_preserved_cwd(repo, item, Path(cwd))
        if item.get('hold'):
            raise LifecycleError('task is held; explicit hold resolution is required')
        if item.get('retire') or item.get('completion_release'):
            raise LifecycleError('task has a retirement request; replay it before starting new use')
        check_run_identity(repo, task)


def _check_preserved_cwd(repo, item, cwd):
    from .preserved import overlap
    for name in _preserved_paths(item):
        boundary = Path(repo) / name
        if cwd == boundary or boundary in cwd.parents:
            raise LifecycleError('managed cwd belongs to foreign preserved data')


def check_preserved_cwd(cwd):
    # Inspect outer managed roots before probing a retired payload as live Git.
    for ancestor in reversed((cwd, *cwd.parents)):
        if not (ancestor / '.git').exists():
            continue
        root = git(ancestor, 'rev-parse', '--show-toplevel', optional=True)
        if root is None or Path(root).resolve() != ancestor:
            continue
        common = Path(git(ancestor, 'rev-parse', '--path-format=absolute', '--git-common-dir'))
        if not (common / 'workspace-lifecycle' / 'state.json').is_file():
            continue
        with locked_state(ancestor) as (_, state):
            try:
                item = _task(state, bound_task(ancestor))
            except LifecycleError:
                continue
            _check_preserved_cwd(ancestor, item, cwd)
