from __future__ import annotations

import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys
import os
import subprocess

from . import __version__

from .errors import LifecycleError
from . import service
from .git import bound_task, common_dir, worktree_records
from .state import locked_state, save_state


def _json_list(value: str):
    result = json.loads(value)
    if not isinstance(result, list) or not all(isinstance(x, str) for x in result):
        raise argparse.ArgumentTypeError("must be a JSON string array")
    return result


def parser():
    root = argparse.ArgumentParser(prog="workspace-lifecycle")
    root.add_argument("--version", action="version", version=__version__)
    root.add_argument("--repo", default=".")
    commands = root.add_subparsers(dest="command", required=True)
    begin = commands.add_parser("begin")
    for name in ("task", "request", "remote", "branch", "worktree"): begin.add_argument("--" + name, required=True)
    begin.add_argument("--parent"); begin.add_argument("--dependency", action="append", default=[])
    begin.add_argument("--validation-json", type=_json_list, default=[], help="validation argv array; an element equal to {repo} resolves to the current validation checkout, including the integration destination; embedded placeholders are unchanged")
    begin.add_argument("--preflight-json", type=_json_list, required=True)
    adopt = commands.add_parser('adopt-existing', help='adopt an existing linked checkout as unaccepted current work')
    for name in ('task', 'request', 'remote', 'branch', 'worktree', 'expected-head', 'evidence'):
        adopt.add_argument('--' + name, required=True)
    adopt.add_argument('--parent'); adopt.add_argument('--dependency', action='append', default=[])
    adopt.add_argument('--validation-json', type=_json_list, required=True, help="validation argv array; an element equal to {repo} resolves to the current validation checkout, including the integration destination; embedded placeholders are unchanged")
    adopt.add_argument('--preflight-json', type=_json_list, required=True)
    adopt.add_argument('--preserved-data-json', type=json.loads, help='explicit foreign retired payload boundaries with current payload/admin identities and evidence references')
    adopt.add_argument('--hold-reason'); adopt.add_argument('--next-action')
    status = commands.add_parser("status"); status.add_argument("--task")
    producer = commands.add_parser('register-owner-receipt', help='bind an exact producer generation before it writes outputs')
    for name in ('task', 'owner', 'generation', 'receipt'):
        producer.add_argument('--' + name, required=True)
    producer.add_argument('--output', action='append', required=True)
    producer.add_argument('--completion-json', type=_json_list, required=True)
    update = commands.add_parser('update-preflight', help='replace one current task preflight by exact argv CAS')
    update.add_argument('--task', required=True)
    update.add_argument('--expected-preflight-json', type=_json_list, required=True)
    update.add_argument('--preflight-json', type=_json_list, required=True)
    update.add_argument('--evidence', required=True)
    validation = commands.add_parser('update-validation',
        help='correct an unaccepted task validator by exact argv and HEAD CAS in its bound checkout')
    validation.add_argument('--task', required=True)
    validation.add_argument('--expected-head', required=True, help='exact full current commit OID')
    validation.add_argument('--expected-validation-json', type=_json_list, required=True)
    validation.add_argument('--validation-json', type=_json_list, required=True,
        help='nonempty argv executed by finish in the candidate and integration checkout')
    validation.add_argument('--evidence', required=True, help='durable reference explaining the correction')
    sync = commands.add_parser('sync', help='resume the same task by an exact same-name remote merge; does not accept or integrate work')
    for name in ('task', 'expected-head', 'remote-head', 'evidence'):
        sync.add_argument('--' + name, required=True)
    hold = commands.add_parser("hold"); hold.add_argument("--task", required=True); hold.add_argument("--reason", required=True); hold.add_argument("--next-action", required=True)
    resume = commands.add_parser('release-hold', help='resolve an explicit hold using a decision reference')
    resume.add_argument('--task', required=True); resume.add_argument('--evidence', required=True)
    finish = commands.add_parser("finish", description="Resolve owned dirty, validate, save, push and normally integrate one task.",
        epilog='Plan: commit/restore/archive arrays of path, owner, evidence, classification and sha256; source requires safe_to_commit=true. Restore requires regeneration.evidence; private archive requires store and approval_evidence. Exception requires reviewed_all_alternatives=true and commit/restore/archive/owner-resolution evidence, irreversible_harm, remaining_owner and next_action.'); finish.add_argument("--task", required=True); finish.add_argument("--plan", required=True); finish.add_argument("--result-ref", required=True); finish.add_argument("--message", default="workspace lifecycle completion"); finish.add_argument("--users-released", action="store_true"); finish.add_argument("--revise-plan-evidence", help="durable review of a revised finish plan or an untouched stale intent with --revise-plan-head"); finish.add_argument("--revise-plan-head", help="exact descendant commit OID for an untouched stale finish intent; requires --revise-plan-evidence"); finish.add_argument("--reclaim-preservation-evidence", help="durable preservation evidence used to start reclaim after retirement")
    retire = commands.add_parser("retire"); retire.add_argument("--task"); retire.add_argument("--result-ref"); retire.add_argument("--pending", action="store_true"); retire.add_argument("--users-released", action="store_true"); retire.add_argument("--request", action="store_true"); retire.add_argument("--reclaim-preservation-evidence", help="durable preservation evidence used to start reclaim after retirement")
    reclaim = commands.add_parser("reclaim"); reclaim.add_argument("--task"); reclaim.add_argument("--result-ref"); reclaim.add_argument("--preservation-evidence"); reclaim.add_argument("--pending", action="store_true")
    run = commands.add_parser("run"); run.add_argument("--task", required=True); run.add_argument("--cwd", default="."); run.add_argument("argv", nargs=argparse.REMAINDER)
    resolve = commands.add_parser("resolve-run", help="Run unmanaged work directly or supervise an already managed task.")
    resolve.add_argument("--cwd", required=True, help="effective workspace directory selected by the caller")
    resolve.add_argument("--launch-cwd", required=True, help="invocation directory used to resolve native relative arguments")
    resolve.add_argument("argv", nargs=argparse.REMAINDER)
    lease_status = commands.add_parser("lease-status"); lease_status.add_argument("--task", required=True)
    release = commands.add_parser("lease-release"); release.add_argument("--task", required=True); release.add_argument("--token", required=True); release.add_argument("--evidence", required=True)
    return root


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        if args.command == "begin": result = service.begin(args.repo, task=args.task, request=args.request, remote=args.remote, branch=args.branch, worktree=args.worktree, parent=args.parent, dependencies=args.dependency, validation=args.validation_json, preflight=args.preflight_json)
        elif args.command == 'adopt-existing':
            from .adoption import adopt_existing
            result = adopt_existing(args.repo, task=args.task, request=args.request, remote=args.remote,
                branch=args.branch, worktree=args.worktree, expected_head=args.expected_head,
                evidence=args.evidence, parent=args.parent, dependencies=args.dependency,
                validation=args.validation_json, preflight=args.preflight_json,
                hold_reason=args.hold_reason, next_action=args.next_action,
                preserved_data=args.preserved_data_json)
        elif args.command == 'sync':
            result = service.synchronize(args.repo, task=args.task, expected_head=args.expected_head,
                                         remote_head=args.remote_head, evidence=args.evidence)
        elif args.command == "status": result = service.status(args.repo, args.task)
        elif args.command == 'update-preflight':
            result = service.update_preflight(args.repo, task=args.task,
                expected_preflight=args.expected_preflight_json,
                preflight=args.preflight_json, evidence=args.evidence)
        elif args.command == 'update-validation':
            result = service.update_validation(args.repo, task=args.task, expected_head=args.expected_head,
                expected_validation=args.expected_validation_json,
                validation=args.validation_json, evidence=args.evidence)
        elif args.command == 'register-owner-receipt':
            from . import producers
            result = producers.register(args.repo, args.task, args.owner, args.generation,
                                        args.receipt, args.output, args.completion_json)
        elif args.command == "hold": result = service.hold(args.repo, args.task, args.reason, args.next_action)
        elif args.command == "release-hold": result = service.release_hold(args.repo, args.task, args.evidence)
        elif args.command == "finish": result = service.finish(args.repo, task=args.task, plan_path=args.plan, result_ref=args.result_ref, message=args.message, users_released=args.users_released, revision_evidence=args.revise_plan_evidence, revision_head=args.revise_plan_head, preservation_evidence=args.reclaim_preservation_evidence)
        elif args.command == "retire":
            if args.pending:
                if args.task or args.result_ref: raise LifecycleError("retire --pending takes no task or result reference")
                if args.reclaim_preservation_evidence: raise LifecycleError("retire --pending rejects --reclaim-preservation-evidence")
                result = service.retire_pending(args.repo)
            elif args.task and args.result_ref: result = service.retire(args.repo, task=args.task, result_ref=args.result_ref, users_released=args.users_released, request_only=args.request, preservation_evidence=args.reclaim_preservation_evidence)
            else: raise LifecycleError("retire requires --task and --result-ref")
        elif args.command == "reclaim":
            if args.pending:
                if args.task or args.result_ref or args.preservation_evidence:
                    raise LifecycleError('reclaim --pending takes no task, result reference or evidence')
                result = service.reclaim_pending(args.repo)
            elif args.task and args.result_ref and args.preservation_evidence:
                result = service.reclaim(args.repo, task=args.task, result_ref=args.result_ref, preservation_evidence=args.preservation_evidence)
            else:
                raise LifecycleError('reclaim requires --task, --result-ref and --preservation-evidence, or --pending')
        elif args.command in {"run", "resolve-run"}:
            argv = args.argv[1:] if args.argv[:1] == ['--'] else args.argv
            if not argv:
                raise LifecycleError(args.command + ' requires an argv after --')
            if args.command == "resolve-run":
                return _resolve_run(args.cwd, args.launch_cwd, argv)
            from .leases import run
            repo = Path(args.repo).resolve()
            cwd = Path(args.cwd).resolve()
            if cwd != repo and repo not in cwd.parents:
                raise LifecycleError('run cwd must be inside the selected task worktree')
            service.check_run_identity(repo, args.task)
            recovery = _recover_selected_task(repo, args.task)
            if recovery['error']:
                raise LifecycleError(recovery['error'])
            if recovery['terminal']:
                return 0
            code = run(repo, args.task, argv, cwd,
                       before_spawn=lambda: service.before_run(repo, args.task, Path(args.cwd).resolve()),
                       child_env=_managed_context(repo, args.task))
            # Native output and status pass through; management JSON belongs to
            # status/finish, not the program's stdout stream.
            recovery = _recover_selected_task(repo, args.task)
            if recovery['error']:
                print(json.dumps(recovery['report']), file=sys.stderr)
                if code == 0:
                    return 1
            return code if code >= 0 else 128 - code
        elif args.command == "lease-status":
            from .leases import status
            result = {"task": args.task, "lease": status(args.repo, args.task)}
        else:
            from .leases import release
            release(args.repo, args.task, args.token, args.evidence); result = {"task": args.task, "released": True}
    except (LifecycleError, ValueError, OSError, subprocess.CalledProcessError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}), file=sys.stderr); return 2
    if _reclaim_refused(result):
        print(json.dumps({"ok": False, **result}, sort_keys=True)); return 1
    print(json.dumps({"ok": True, **result}, sort_keys=True)); return 0


def _reclaim_refused(result):
    if not isinstance(result, dict):
        return False
    pending = result.get('pending')
    if isinstance(pending, list) and any(isinstance(entry, dict) and entry.get('error')
                                         for entry in pending):
        return True
    if any(not entry.get('reclaimed') for entry in result.get('producers', {}).get('results', [])):
        return True
    reclaim = result.get('reclaim')
    if isinstance(reclaim, dict) and reclaim.get('error'):
        return True
    retirement = result.get('retirement')
    if isinstance(retirement, dict):
        nested = retirement.get('reclaim')
        if isinstance(nested, dict) and nested.get('error'):
            return True
    return False


def _managed_context(repo, task):
    from .producers import task_receipt_dir
    receipt_dir = task_receipt_dir(repo, task)
    service._no_links(receipt_dir)
    receipt_dir.mkdir(parents=True, exist_ok=True)
    prefix = [sys.executable, '-m', 'workspace_lifecycle', '--repo', str(repo)]
    context = json.dumps({'version': 1, 'repo': str(repo), 'task': task,
                          'finish_argv': [*prefix, 'finish', '--task', task],
                          'owner_receipt_argv': [*prefix, 'register-owner-receipt', '--task', task],
                          'owner_receipt_dir': str(receipt_dir)},
                         sort_keys=True, separators=(',', ':'))
    return {'WORKSPACE_LIFECYCLE_CONTEXT': context,
            'WORKSPACE_LIFECYCLE_REPO': str(repo), 'WORKSPACE_LIFECYCLE_TASK': task}


def _recover_selected_task(repo, task):
    """Replay only one durable task recovery before or after its managed use."""
    with locked_state(repo) as (_, state):
        item = state['tasks'].get(task)
        retired = state.get('retired', {}).get(task)
        if item is None and retired is None:
            raise LifecycleError('unknown task: ' + task)
        release = item.get('completion_release') if item else None
        pending_record = deepcopy((item.get('retire') or release) if item else None)
        pending = bool(pending_record) or bool(
            retired and retired.get('preservation_evidence')
            and retired.get('reclaim_phase') not in (None, 'reclaimed'))
    if not pending:
        return {'terminal': item is None, 'error': None,
                'report': {'retire': {'pending': []}, 'reclaim': {'pending': []}}}
    if release:
        from . import leases
        lease = leases.status(repo, task)['receipt']
        if lease is not None:
            try:
                leases.release(repo, task, lease['token'], release['result_ref'])
            except (ValueError, OSError) as exc:
                with locked_state(repo) as (directory, state):
                    current = state['tasks'].get(task)
                    if current and current.get('completion_release') == release:
                        current['completion_release']['lease_recovery_failure'] = str(exc)
                        save_state(directory, state)
    records = worktree_records(repo)
    if not records:
        raise LifecycleError('managed task recovery requires a primary Git worktree')
    control = Path(records[0]['worktree']).resolve()
    os.chdir(control)
    report = {'retire': service.retire_pending(control, task),
              'reclaim': service.reclaim_pending(control, task)}
    error = next((entry.get('error') or 'selected task retirement remains pending'
                  for entry in report['retire']['pending'] if entry.get('error') or not entry.get('retired')), None)
    error = error or next((entry.get('error') or 'selected task reclaim remains pending'
                           for entry in report['reclaim']['pending'] if entry.get('error') or not entry.get('reclaimed')), None)
    with locked_state(control) as (directory, state):
        current = state['tasks'].get(task)
        retired = state.get('retired', {}).get(task)
        current_pending = current and (current.get('retire') or current.get('completion_release'))
        if current_pending and error is None:
            error = 'selected task recovery remains pending'
        if error and current_pending is not None and current_pending == pending_record and current_pending.get('recovery_failure') != error:
            current_pending['recovery_failure'] = error
            save_state(directory, state)
    if error == 'selected task recovery remains pending':
        report['retire']['pending'].append({'task': task, 'retired': False,
                                            'error': error})
    return {'terminal': current is None and retired is not None, 'error': error, 'report': report}


def _native_code(code):
    return code if code >= 0 else 128 - code


def _plain_run(argv, cwd, env=None):
    environment = os.environ if env is None else env
    if os.name == 'posix':
        os.chdir(cwd)
        os.execvpe(argv[0], argv, environment)
    import signal
    signal.signal(signal.SIGBREAK, lambda *_: None)
    child = subprocess.Popen(argv, cwd=cwd, env=environment)
    while True:
        try:
            return _native_code(child.wait())
        except KeyboardInterrupt:
            # Console control events reach the child directly. Keep the thin
            # parent alive until the native command reports its own status.
            continue


def _git_marker(path):
    for candidate in (path, *path.parents):
        marker = candidate / '.git'
        if marker.exists() or marker.is_symlink():
            return marker
    return None


def _resolve_run(effective, launch, argv):
    """Resolve lifecycle ownership without exposing its state schema to callers."""
    effective = Path(effective).resolve()
    launch = Path(launch).resolve()
    service.check_preserved_cwd(effective)
    service.check_preserved_cwd(launch)
    if not effective.is_dir() or not launch.is_dir():
        raise LifecycleError('resolve-run directories must exist')
    probe = subprocess.run(['git', '-C', str(effective), 'rev-parse', '--show-toplevel'],
                           text=True, encoding="utf-8", stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    if probe.returncode:
        if _git_marker(effective) is not None:
            raise LifecycleError('effective cwd has an invalid Git workspace')
        return _plain_run(argv, launch)
    repo = Path(probe.stdout.strip()).resolve()
    if effective != repo and repo not in effective.parents:
        raise LifecycleError('effective cwd is outside its resolved Git worktree')
    common = common_dir(repo)
    if (common / 'agent-branches' / 'state.json').exists():
        raise LifecycleError('legacy agent-branches registry exists; migration is not authorized')
    lifecycle = common / 'workspace-lifecycle'
    if not lifecycle.exists():
        return _plain_run(argv, launch)
    if not lifecycle.is_dir():
        raise LifecycleError('workspace lifecycle state is not a directory')
    task = bound_task(repo)
    from .leases import run
    service.check_run_identity(repo, task)
    recovery = _recover_selected_task(repo, task)
    if recovery['error']:
        raise LifecycleError(recovery['error'])
    if recovery['terminal']:
        return 0
    code = run(repo, task, argv, launch,
               before_spawn=lambda: service.before_run(repo, task, launch),
               child_env=_managed_context(repo, task))
    recovery = _recover_selected_task(repo, task)
    if recovery['error']:
        print(json.dumps(recovery['report']), file=sys.stderr)
        return 1 if code == 0 else _native_code(code)
    return _native_code(code)


if __name__ == "__main__": raise SystemExit(main())
